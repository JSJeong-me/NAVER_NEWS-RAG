
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class SymbolInfo:
    symbol: str
    name_kr: str
    name_en: Optional[str] = None
    aliases: List[str] | None = None


class SymbolDictionary:
    """In-memory dictionary of all tradable symbols."""

    def __init__(self) -> None:
        self._symbols: List[SymbolInfo] = []

    def load(self) -> None:
        """Load symbol list from external source (DB/file/API)."""
        raise NotImplementedError

    def get_all(self) -> List[SymbolInfo]:
        return self._symbols

    def find_by_symbol(self, symbol: str) -> Optional[SymbolInfo]:
        """Return SymbolInfo matching symbol (if any)."""
        raise NotImplementedError
