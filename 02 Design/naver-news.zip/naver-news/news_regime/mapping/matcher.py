
from __future__ import annotations
from typing import List

from news_regime.domain.models import NewsArticleDetail, SymbolMatch
from .symbol_dictionary import SymbolDictionary


class SymbolMatcher:
    """Heuristic matcher from article text to one or more symbols."""

    def __init__(self, symbol_dict: SymbolDictionary) -> None:
        self.symbol_dict = symbol_dict

    def match_symbols(self, article: NewsArticleDetail) -> List[SymbolMatch]:
        """Return list of SymbolMatch for given article."""
        raise NotImplementedError
