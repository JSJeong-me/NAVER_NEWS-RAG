
from __future__ import annotations
from datetime import datetime
from typing import Optional

from news_regime.config.models import RegimeConfig
from news_regime.domain.models import GlobalNewsStats, RegimeStatus


class RegimeClassifier:
    """Rule-based regime classifier with optional LLM explanation."""

    def __init__(self, config: RegimeConfig, summarizer: Optional[object] = None) -> None:
        self.config = config
        self.summarizer = summarizer

    def classify(self, stats: GlobalNewsStats, as_of: datetime) -> RegimeStatus:
        raise NotImplementedError
