
from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo


class TimeParser:
    """Parses Naver-style time strings into timezone-aware datetime."""

    def __init__(self, timezone: str) -> None:
        self.timezone = timezone

    def parse_published_time(self, raw_time_str: str) -> datetime:
        """Parse raw Naver time string like '2025.12.02 10:30'."""
        raise NotImplementedError
