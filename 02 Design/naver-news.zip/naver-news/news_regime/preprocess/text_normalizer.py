
from __future__ import annotations


class TextNormalizer:
    """Basic HTML/text cleanup utilities."""

    def strip_html(self, html: str) -> str:
        """Remove tags and return plain text."""
        raise NotImplementedError

    def normalize_whitespace(self, text: str) -> str:
        """Normalize whitespace and linebreaks."""
        raise NotImplementedError

    def normalize_text(self, html_or_text: str) -> str:
        """Full pipeline for article body normalisation."""
        raise NotImplementedError
