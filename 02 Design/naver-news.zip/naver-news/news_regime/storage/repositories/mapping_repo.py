
from __future__ import annotations
from typing import List

from news_regime.domain.models import SymbolMatch


class SymbolMapRepository:
    """Persist news-symbol mapping rows."""

    def insert_mappings(self, session, mappings: List[SymbolMatch]) -> None:
        raise NotImplementedError

    def get_mappings_for_news_ids(self, session, news_ids: List[str]) -> List[SymbolMatch]:
        raise NotImplementedError
