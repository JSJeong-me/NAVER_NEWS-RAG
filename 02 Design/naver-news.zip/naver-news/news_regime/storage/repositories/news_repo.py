
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.domain.models import NewsArticleMeta, NewsArticleDetail, ArticleSentiment


class NewsRepository:
    """CRUD operations for news metadata & article bodies."""

    def exists_by_url(self, session, url: str) -> bool:
        raise NotImplementedError

    def insert_news_meta(self, session, meta: NewsArticleMeta) -> str:
        raise NotImplementedError

    def insert_news_detail(self, session, detail: NewsArticleDetail, news_id: str) -> None:
        raise NotImplementedError

    def get_news_in_window(
        self,
        session,
        start: datetime,
        end: datetime,
    ) -> List[NewsArticleMeta]:
        raise NotImplementedError
