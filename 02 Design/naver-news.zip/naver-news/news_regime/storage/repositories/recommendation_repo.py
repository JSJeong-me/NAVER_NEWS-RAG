
from __future__ import annotations
from typing import List

from news_regime.domain.models import RecommendationItem


class RecommendationRepository:
    """Persist recommendation snapshots."""

    def insert_recommendations(self, session, items: List[RecommendationItem]) -> None:
        raise NotImplementedError

    def get_latest_recommendations(self, session, limit: int = 50) -> List[RecommendationItem]:
        raise NotImplementedError
