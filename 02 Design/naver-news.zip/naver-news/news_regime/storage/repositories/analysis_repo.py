
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.domain.models import ArticleSentiment


class AnalysisRepository:
    """Persist article-level sentiment/risk/impact records."""

    def insert_article_analysis(self, session, analyses: List[ArticleSentiment]) -> None:
        raise NotImplementedError

    def get_article_analysis_in_window(
        self,
        session,
        start: datetime,
        end: datetime,
    ) -> List[ArticleSentiment]:
        raise NotImplementedError
