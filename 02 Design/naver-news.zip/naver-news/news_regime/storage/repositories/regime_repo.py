
from __future__ import annotations
from typing import List

from news_regime.domain.models import RegimeStatus


class RegimeRepository:
    """Persist regime classification history."""

    def insert_regime(self, session, regime: RegimeStatus) -> None:
        raise NotImplementedError

    def get_recent_regimes(self, session, limit: int = 50) -> List[RegimeStatus]:
        raise NotImplementedError
