
from __future__ import annotations
from typing import Any
from news_regime.config.models import DbConfig


class DbSessionManager:
    """Thin wrapper over DB engine/session creation (SQLAlchemy or similar)."""

    def __init__(self, config: DbConfig) -> None:
        self.config = config
        # TODO: initialise engine/connection pool here.

    def create_session(self) -> Any:
        """Return a DB session or connection object."""
        raise NotImplementedError
