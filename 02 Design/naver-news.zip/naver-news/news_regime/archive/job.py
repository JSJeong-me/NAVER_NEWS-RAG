
from __future__ import annotations
from datetime import datetime

from news_regime.storage.db import DbSessionManager
from news_regime.archive.planner import ArchivePlanner
from news_regime.archive.exporter import ArchiveExporter
from news_regime.archive.cleaner import ArchiveCleaner


class ArchiveJob:
    """High-level daily archive job orchestration."""

    def __init__(
        self,
        session_manager: DbSessionManager,
        planner: ArchivePlanner,
        exporter: ArchiveExporter,
        cleaner: ArchiveCleaner,
    ) -> None:
        self.session_manager = session_manager
        self.planner = planner
        self.exporter = exporter
        self.cleaner = cleaner

    def run(self, as_of: datetime) -> None:
        raise NotImplementedError
