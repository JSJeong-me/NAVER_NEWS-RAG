
from __future__ import annotations
from typing import Iterable, Any


class ArchiveExporter:
    """Exports DB rows into files (e.g. Parquet/CSV) on disk."""

    def export_rows(self, rows: Iterable[Any], dest_path: str) -> None:
        raise NotImplementedError
