
from __future__ import annotations


class ArchiveCleaner:
    """Deletes archived rows from DB after they are exported."""

    def delete_archived_rows(self, session, cutoff_time) -> None:
        raise NotImplementedError
