
from __future__ import annotations
from typing import Optional
from .models import AppConfig, DbConfig, CrawlConfig, AnalysisConfig, RegimeConfig, ArchiveConfig, LlmConfig


class ConfigLoader:
    """Stub loader: wire YAML/ENV loading here later."""

    def __init__(self, env: Optional[str] = None) -> None:
        self.env = env or "dev"

    def load(self) -> AppConfig:
        """Return a minimal AppConfig instance (placeholder)."""
        # NOTE: fill this with real YAML/ENV parsing logic later.
        db = DbConfig(dsn="sqlite:///news_regime.db")
        crawl = CrawlConfig(base_url="https://finance.naver.com")
        analysis = AnalysisConfig()
        regime = RegimeConfig()
        archive = ArchiveConfig()
        llm = LlmConfig()
        return AppConfig(
            db=db,
            crawl=crawl,
            analysis=analysis,
            regime=regime,
            archive=archive,
            llm=llm,
        )


def get_config(env: Optional[str] = None) -> AppConfig:
    """Convenience helper to get AppConfig (could be cached/singleton)."""
    loader = ConfigLoader(env=env)
    return loader.load()
