
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.config.models import CrawlConfig
from news_regime.crawler.http_client import HttpClient
from news_regime.domain.models import NewsArticleMeta, NewsArticleDetail
from news_regime.parser.mainnews_parser import MainNewsParser
from news_regime.parser.article_parser import ArticleParser


class NaverNewsClient:
    """Fetches and parses Naver Finance mainnews and article pages."""

    def __init__(
        self,
        http_client: HttpClient,
        crawl_config: CrawlConfig,
        mainnews_parser: MainNewsParser,
        article_parser: ArticleParser,
    ) -> None:
        self.http_client = http_client
        self.crawl_config = crawl_config
        self.mainnews_parser = mainnews_parser
        self.article_parser = article_parser

    def fetch_mainnews_page(self) -> str:
        """Return HTML text of mainnews page."""
        raise NotImplementedError

    def fetch_article_page(self, article_url: str) -> str:
        """Return HTML text of a single article page."""
        raise NotImplementedError

    def crawl_mainnews(self, crawled_at: datetime) -> List[NewsArticleMeta]:
        """Fetch + parse mainnews page into a list of NewsArticleMeta."""
        raise NotImplementedError

    def crawl_article_detail(self, meta: NewsArticleMeta) -> NewsArticleDetail:
        """Fetch + parse a full article body for given metadata."""
        raise NotImplementedError
