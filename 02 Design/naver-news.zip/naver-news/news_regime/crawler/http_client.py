
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class HttpResponse:
    url: str
    status_code: int
    headers: Dict[str, str]
    text: str
    elapsed_sec: float


class HttpClient:
    """Thin HTTP client abstraction.

    Real implementation should use httpx/requests with retry & rate limiting.
    """

    def __init__(self, base_url: str, timeout: float, user_agent: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.user_agent = user_agent

    def get(self, path: str, params: Optional[Dict[str, str]] = None) -> HttpResponse:
        """Perform GET to base_url + path and return HttpResponse.

        NOTE: this is a stub; fill in with real HTTP code.
        """
        raise NotImplementedError
