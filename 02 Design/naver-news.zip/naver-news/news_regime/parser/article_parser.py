
from __future__ import annotations

from news_regime.domain.models import NewsArticleMeta, NewsArticleDetail


class ArticleParser:
    """Parses Naver article HTML into NewsArticleDetail."""

    def parse(self, html: str, meta: NewsArticleMeta) -> NewsArticleDetail:
        """Return NewsArticleDetail from article HTML and metadata."""
        raise NotImplementedError
