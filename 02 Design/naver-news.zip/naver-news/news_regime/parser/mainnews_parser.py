
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.domain.models import NewsArticleMeta


class MainNewsParser:
    """Parses Naver Finance mainnews HTML into NewsArticleMeta objects."""

    def parse(self, html: str, crawled_at: datetime) -> List[NewsArticleMeta]:
        """Return list of NewsArticleMeta from a mainnews page HTML."""
        raise NotImplementedError
