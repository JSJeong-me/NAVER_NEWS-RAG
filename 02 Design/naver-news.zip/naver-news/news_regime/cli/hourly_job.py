
from __future__ import annotations
from datetime import datetime

from news_regime.common.logging import setup_logging
from news_regime.common.time_utils import now_in_timezone
from news_regime.config.loader import get_config
from news_regime.storage.db import DbSessionManager
from news_regime.crawler.http_client import HttpClient
from news_regime.crawler.naver_client import NaverNewsClient
from news_regime.parser.mainnews_parser import MainNewsParser
from news_regime.parser.article_parser import ArticleParser
from news_regime.preprocess.text_normalizer import TextNormalizer
from news_regime.preprocess.time_utils import TimeParser
from news_regime.mapping.symbol_dictionary import SymbolDictionary
from news_regime.mapping.matcher import SymbolMatcher
from news_regime.storage.repositories.news_repo import NewsRepository
from news_regime.storage.repositories.mapping_repo import SymbolMapRepository
from news_regime.storage.repositories.analysis_repo import AnalysisRepository
from news_regime.analysis.sentiment import RuleBasedSentimentAnalyzer
from news_regime.analysis.risk import RuleBasedRiskTagger
from news_regime.analysis.impact import ImpactScorer
from news_regime.analysis.aggregator import AggregationService
from news_regime.recommend.policy import RecommendationPolicy
from news_regime.recommend.engine import RecommendationEngine
from news_regime.regime.classifier import RegimeClassifier
from news_regime.storage.repositories.recommendation_repo import RecommendationRepository
from news_regime.storage.repositories.regime_repo import RegimeRepository
from news_regime.llm.client import LlmClient
from news_regime.llm.summarizer import NewsSummarizer
from news_regime.llm.classifier import NewsClassifier


class HourlyJob:
    """Orchestrates 1-hour cycle: crawl -> analyze -> recommend -> regime."""

    def __init__(self) -> None:
        self.config = get_config()
        setup_logging(self.config.log_level)

        # DB
        self.session_manager = DbSessionManager(self.config.db)

        # LLM
        self.llm_client = LlmClient(
            model_name=self.config.llm.model_name,
            temperature=self.config.llm.temperature,
            max_tokens=self.config.llm.max_tokens,
            request_timeout=self.config.llm.request_timeout,
        )
        self.news_summarizer = NewsSummarizer(self.llm_client)
        self.news_classifier = NewsClassifier(self.llm_client)

        # HTTP / crawling
        self.http_client = HttpClient(
            base_url=self.config.crawl.base_url,
            timeout=self.config.crawl.request_timeout,
            user_agent=self.config.crawl.user_agent,
        )
        self.time_parser = TimeParser(self.config.timezone)
        self.mainnews_parser = MainNewsParser()
        self.article_parser = ArticleParser()
        self.text_normalizer = TextNormalizer()
        self.naver_client = NaverNewsClient(
            http_client=self.http_client,
            crawl_config=self.config.crawl,
            mainnews_parser=self.mainnews_parser,
            article_parser=self.article_parser,
        )

        # Mapping
        self.symbol_dict = SymbolDictionary()
        self.symbol_matcher = SymbolMatcher(self.symbol_dict)

        # Analysis
        self.sentiment_analyzer = RuleBasedSentimentAnalyzer()
        self.risk_tagger = RuleBasedRiskTagger()
        self.impact_scorer = ImpactScorer()
        self.aggregator = AggregationService()

        # Recommendation & Regime
        self.reco_policy = RecommendationPolicy(self.config.analysis)
        self.reco_engine = RecommendationEngine(self.reco_policy, summarizer=self.news_summarizer)
        self.regime_classifier = RegimeClassifier(self.config.regime, summarizer=self.news_summarizer)

        # Repositories
        self.news_repo = NewsRepository()
        self.mapping_repo = SymbolMapRepository()
        self.analysis_repo = AnalysisRepository()
        self.reco_repo = RecommendationRepository()
        self.regime_repo = RegimeRepository()

    def run_once(self, now: datetime | None = None) -> None:
        """Run one hourly cycle. Implementation is stubbed."""
        raise NotImplementedError


def main() -> None:
    job = HourlyJob()
    now = now_in_timezone(job.config.timezone)
    job.run_once(now=now)


if __name__ == "__main__":
    main()
