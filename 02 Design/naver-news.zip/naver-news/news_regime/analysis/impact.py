
from __future__ import annotations
from news_regime.domain.models import NewsArticleDetail


class ImpactScorer:
    """Assign a rough impact score to each article (0~1)."""

    def score(self, article: NewsArticleDetail) -> float:
        raise NotImplementedError
