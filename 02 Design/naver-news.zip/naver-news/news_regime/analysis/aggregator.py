
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.domain.models import (
    ArticleSentiment,
    SymbolAggregatedStats,
    GlobalNewsStats,
    SymbolMatch,
)


class AggregationService:
    """Aggregate article-level results into symbol & global stats."""

    def aggregate_by_symbol(
        self,
        sentiments: List[ArticleSentiment],
        symbol_map: List[SymbolMatch],
        window_start: datetime,
        window_end: datetime,
    ) -> List[SymbolAggregatedStats]:
        raise NotImplementedError

    def aggregate_global(
        self,
        sentiments: List[ArticleSentiment],
        window_start: datetime,
        window_end: datetime,
    ) -> GlobalNewsStats:
        raise NotImplementedError
