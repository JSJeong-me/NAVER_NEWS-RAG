
from __future__ import annotations
from news_regime.domain.models import NewsArticleDetail


class SentimentAnalyzer:
    """Base interface for sentiment analyzers."""

    def analyze(self, article: NewsArticleDetail) -> float:
        raise NotImplementedError


class RuleBasedSentimentAnalyzer(SentimentAnalyzer):
    """Simple keyword/dictionary-based sentiment scoring stub."""

    def analyze(self, article: NewsArticleDetail) -> float:
        raise NotImplementedError
