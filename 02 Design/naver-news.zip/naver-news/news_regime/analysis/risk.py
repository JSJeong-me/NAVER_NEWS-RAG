
from __future__ import annotations
from dataclasses import dataclass
from news_regime.domain.models import NewsArticleDetail


@dataclass
class RiskFlags:
    regulatory_risk: bool
    earnings_risk: bool
    credit_risk: bool


class RiskTagger:
    """Base interface for risk tagging."""

    def tag(self, article: NewsArticleDetail) -> RiskFlags:
        raise NotImplementedError


class RuleBasedRiskTagger(RiskTagger):
    """Keyword-based risk tagging stub."""

    def tag(self, article: NewsArticleDetail) -> RiskFlags:
        raise NotImplementedError
