
from __future__ import annotations
from datetime import datetime
from typing import List, Optional

from news_regime.domain.models import SymbolAggregatedStats, RecommendationItem
from .policy import RecommendationPolicy


class RecommendationEngine:
    """Builds RecommendationItem list from aggregated stats."""

    def __init__(self, policy: RecommendationPolicy, summarizer: Optional[object] = None) -> None:
        self.policy = policy
        self.summarizer = summarizer  # LLM-based summarizer (optional)

    def generate_recommendations(
        self,
        aggregated_stats: List[SymbolAggregatedStats],
        as_of: datetime,
        top_n: int | None = None,
    ) -> List[RecommendationItem]:
        raise NotImplementedError
