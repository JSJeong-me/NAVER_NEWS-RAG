
from __future__ import annotations
from news_regime.config.models import AnalysisConfig
from news_regime.domain.models import SymbolAggregatedStats


class RecommendationPolicy:
    """Rule-based filter & scoring for buy candidates."""

    def __init__(self, config: AnalysisConfig) -> None:
        self.config = config

    def is_buy_candidate(self, stats: SymbolAggregatedStats) -> bool:
        raise NotImplementedError

    def compute_composite_score(self, stats: SymbolAggregatedStats) -> float:
        raise NotImplementedError
