
from __future__ import annotations


class ArchiveCleaner:
    """Deletes archived rows from DB after they are exported."""

    def delete_archived_rows(self, session, cutoff_time) -> None:
        """Delete archived rows from in-memory storage."""
        # Remove old news metadata
        old_ids = []
        for news_id, meta in list(session.get("news_meta", {}).items()):
            if meta.crawled_at < cutoff_time:
                old_ids.append(news_id)
        
        for news_id in old_ids:
            session["news_meta"].pop(news_id, None)
            session["news_detail"].pop(news_id, None)
