
from __future__ import annotations
from datetime import datetime

from news_regime.storage.db import DbSessionManager
from news_regime.archive.planner import ArchivePlanner
from news_regime.archive.exporter import ArchiveExporter
from news_regime.archive.cleaner import ArchiveCleaner


class ArchiveJob:
    """High-level daily archive job orchestration."""

    def __init__(
        self,
        session_manager: DbSessionManager,
        planner: ArchivePlanner,
        exporter: ArchiveExporter,
        cleaner: ArchiveCleaner,
    ) -> None:
        self.session_manager = session_manager
        self.planner = planner
        self.exporter = exporter
        self.cleaner = cleaner

    def run(self, as_of: datetime) -> None:
        """Execute archive job: plan -> export -> clean."""
        import logging
        logger = logging.getLogger(__name__)
        
        # Build plan
        plan = self.planner.build_plan(as_of)
        logger.info(f"Archive plan: cutoff={plan.cutoff_time}, retention={plan.retention_days} days")
        
        # Get session
        session = self.session_manager.create_session()
        
        # Export old rows (simplified)
        old_news = [meta for meta in session.get("news_meta", {}).values() 
                   if meta.crawled_at < plan.cutoff_time]
        if old_news:
            dest_path = f"./archive/news_{plan.cutoff_time.date()}.parquet"
            self.exporter.export_rows(old_news, dest_path)
            logger.info(f"Exported {len(old_news)} news articles")
        
        # Clean old rows
        self.cleaner.delete_archived_rows(session, plan.cutoff_time)
        logger.info("Archive job complete")
