
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta

from news_regime.config.models import ArchiveConfig


@dataclass
class ArchivePlan:
    cutoff_time: datetime
    retention_days: int


class ArchivePlanner:
    """Compute which rows should be archived based on retention_days."""

    def __init__(self, config: ArchiveConfig) -> None:
        self.config = config

    def build_plan(self, as_of: datetime) -> ArchivePlan:
        """Return ArchivePlan that defines archive cutoff time."""
        cutoff = as_of - timedelta(days=self.config.retention_days)
        return ArchivePlan(
            cutoff_time=cutoff,
            retention_days=self.config.retention_days,
        )
