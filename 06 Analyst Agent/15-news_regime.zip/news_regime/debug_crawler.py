
import httpx
from news_regime.config.models import CrawlConfig

config = CrawlConfig(base_url="https://finance.naver.com")
url = f"{config.base_url}{config.mainnews_path}"
print(f"Fetching {url}...")

headers = {"User-Agent": config.user_agent}
response = httpx.get(url, headers=headers, timeout=10.0)
print(f"Status: {response.status_code}")

with open("mainnews.html", "w", encoding="utf-8") as f:
    f.write(response.text)
print("Saved to mainnews.html")
