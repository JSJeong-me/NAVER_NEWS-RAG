
from __future__ import annotations
from datetime import datetime, timedelta
from typing import Dict, Any

from news_regime.storage.db import DbSessionManager
from news_regime.storage.repositories.news_repo import NewsRepository
from news_regime.storage.repositories.analysis_repo import AnalysisRepository
from news_regime.storage.repositories.recommendation_repo import RecommendationRepository
from news_regime.storage.repositories.regime_repo import RegimeRepository


class QueryService:
    """Read-only API for UI/other systems to query news/regime state."""

    def __init__(
        self,
        session_manager: DbSessionManager,
        news_repo: NewsRepository,
        analysis_repo: AnalysisRepository,
        reco_repo: RecommendationRepository,
        regime_repo: RegimeRepository,
        summarizer: object | None = None,
    ) -> None:
        self.session_manager = session_manager
        self.news_repo = news_repo
        self.analysis_repo = analysis_repo
        self.reco_repo = reco_repo
        self.regime_repo = regime_repo
        self.summarizer = summarizer

    def get_symbol_news_summary(
        self,
        symbol: str,
        window_hours: int = 24,
    ) -> Dict[str, Any]:
        raise NotImplementedError

    def get_latest_recommendations(self, limit: int = 20) -> Dict[str, Any]:
        raise NotImplementedError

    def get_latest_regime(self) -> Dict[str, Any]:
        raise NotImplementedError
