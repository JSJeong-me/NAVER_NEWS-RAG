#!/usr/bin/env python
"""
Crawl Naver Finance news and search by keyword.

USAGE:
    python -m crawl_and_search

Note: This must be run using 'python -m' to ensure proper module imports.
"""

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from cli.hourly_job import HourlyJob

def main():
    # Step 1: Crawl news
    print("=" * 60)
    print("STEP 1: Crawling Naver Finance News")
    print("=" * 60)
    
    job = HourlyJob()
    job.run_once()
    
    # Step 2: Access stored data
    print("\n" + "=" * 60)
    print("STEP 2: Searching Archived News")
    print("=" * 60)
    
    session = job.session_manager.create_session()
    
    # Search by keyword
    keyword = "삼성"  # Change this to your keyword
    print(f"\nSearching for: '{keyword}'")
    
    cursor = session.cursor()
    cursor.execute(
        """
        SELECT id, title, url, publisher, category, summary, published_at, crawled_at
        FROM news_meta
        WHERE title LIKE ?
        ORDER BY crawled_at DESC
        LIMIT 20
        """,
        (f"%{keyword}%",),
    )
    results = cursor.fetchall()
    
    print(f"Found {len(results)} articles")
    
    for i, row in enumerate(results[:5], 1):
        print(f"\n{i}. {row['title']}")
        print(f"   Publisher: {row['publisher']}")
        print(f"   Published: {row['published_at']}")
        print(f"   URL: {row['url']}")
    
    # Show recommendations
    print("\n" + "=" * 60)
    print("STEP 3: Buy Recommendations")
    print("=" * 60)
    
    import json
    cursor.execute(
        """
        SELECT symbol, created_at, sentiment_score, impact_score,
               composite_score, risk_summary, status, reason_summary
        FROM recommendations
        ORDER BY created_at DESC
        LIMIT 5
        """
    )
    recommendations = cursor.fetchall()
    if recommendations:
        for i, rec in enumerate(recommendations, 1):
            print(f"\n{i}. Symbol: {rec['symbol']}")
            print(f"   Score: {rec['composite_score']:.2f}")
            if rec['risk_summary']:
                risk_summary = json.loads(rec['risk_summary'])
                print(f"   Risk: {risk_summary}")
            print(f"   Reason: {rec['reason_summary']}")
    else:
        print("No recommendations generated (not enough positive news)")

if __name__ == "__main__":
    main()
