from __future__ import annotations

from datetime import datetime

from .config import AnalystAgentConfig
from .llm_client import LlmClient
from .report_schema import AnalystCoreFindings, AnalystReport


def generate_analyst_report(
    core_findings: AnalystCoreFindings,
    config: AnalystAgentConfig,
    llm_client: LlmClient,
) -> AnalystReport:
    """Generate an AnalystReport from core findings using the LLM."""
    
    # Generate text content
    formatted_text = llm_client.generate_report_text(core_findings)
    
    # Extract a simple header/summary if possible
    summary_header = None
    lines = formatted_text.splitlines()
    for line in lines:
        if line.strip() and not line.startswith("#"):
            summary_header = line.strip()[:100]
            break
            
    return AnalystReport(
        generated_at=datetime.now(),
        config=config,
        core_findings=core_findings,
        formatted_text=formatted_text,
        summary_header=summary_header,
        metadata={
            "model": config.llm.model,
            "regime_window": config.regime_window_size
        }
    )
