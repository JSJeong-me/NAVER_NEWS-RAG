from __future__ import annotations

from typing import Dict, List

from .models import (
    ArticleStats,
    DbSnapshot,
    NewsArticle,
    Recommendation,
    RegimeRecord,
    SymbolStats,
)


def split_query_all_output(raw_output: str) -> Dict[str, str]:
    """Split raw query_db.sh all output into logical sections."""
    sections = {
        "news_articles": "",
        "article_analysis": "",
        "symbol_mappings": "",
        "recommendations": "",
        "regime_history": ""
    }
    
    current_section = None
    lines = raw_output.splitlines()
    buffer = []
    
    # Map headers to section keys
    header_map = {
        "News Articles (": "news_articles",
        "Article Analysis (": "article_analysis",
        "Symbol Mappings (": "symbol_mappings",
        "Recent Recommendations (": "recommendations",
        "Regime History (": "regime_history"
    }
    
    for line in lines:
        # Check if line is a header
        is_header = False
        for header, key in header_map.items():
            if header in line and line.strip().startswith("="):
                # Found a header line (usually surrounded by ===)
                # But wait, the format is usually:
                # ================================================================================
                # News Articles (...)
                # ================================================================================
                pass
            elif header in line:
                # This is the actual header line
                if current_section:
                    sections[current_section] = "\n".join(buffer)
                current_section = key
                buffer = []
                is_header = True
                break
        
        if not is_header:
            if current_section:
                buffer.append(line)
                
    # Flush last section
    if current_section:
        sections[current_section] = "\n".join(buffer)
        
    return sections


def parse_news_section(section_text: str) -> List[NewsArticle]:
    """Parse the 'News Articles' section into NewsArticle objects."""
    import re
    from datetime import datetime
    
    articles = []
    # Regex to find article blocks starting with "N. Title"
    # But simpler to iterate lines
    
    lines = section_text.splitlines()
    current_article = {}
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Match "1. Title"
        match = re.match(r"^(\d+)\.\s+(.+)$", line)
        if match:
            # Save previous if exists
            if current_article:
                articles.append(NewsArticle(
                    index=current_article.get('index', 0),
                    title=current_article.get('title', ''),
                    publisher=current_article.get('publisher', ''),
                    category=current_article.get('category', ''),
                    crawled_at=current_article.get('crawled_at', datetime.now()),
                    url=current_article.get('url', ''),
                    summary_raw=current_article.get('summary', '')
                ))
            
            current_article = {
                'index': int(match.group(1)),
                'title': match.group(2)
            }
            continue
            
        if not current_article:
            continue
            
        if line.startswith("Publisher:"):
            current_article['publisher'] = line.replace("Publisher:", "").strip()
        elif line.startswith("Category:"):
            current_article['category'] = line.replace("Category:", "").strip()
        elif line.startswith("Crawled:"):
            dt_str = line.replace("Crawled:", "").strip()
            try:
                current_article['crawled_at'] = datetime.fromisoformat(dt_str)
            except ValueError:
                current_article['crawled_at'] = datetime.now()
        elif line.startswith("URL:"):
            current_article['url'] = line.replace("URL:", "").strip()
        elif line.startswith("Summary:"):
            current_article['summary'] = line.replace("Summary:", "").strip()
            
    # Append last one
    if current_article:
        articles.append(NewsArticle(
            index=current_article.get('index', 0),
            title=current_article.get('title', ''),
            publisher=current_article.get('publisher', ''),
            category=current_article.get('category', ''),
            crawled_at=current_article.get('crawled_at', datetime.now()),
            url=current_article.get('url', ''),
            summary_raw=current_article.get('summary', '')
        ))
        
    return articles


def parse_article_analysis_section(section_text: str) -> ArticleStats:
    """Parse the 'Article Analysis' section into ArticleStats."""
    stats = ArticleStats(0, 0.0, 0.0, 0, 0, 0)
    
    for line in section_text.splitlines():
        line = line.strip()
        if "Total Articles Analyzed:" in line:
            try:
                stats.total_articles = int(line.split(":")[-1].strip())
            except: pass
        elif "Average Sentiment Score:" in line:
            try:
                stats.avg_sentiment = float(line.split(":")[-1].strip())
            except: pass
        elif "Average Impact Score:" in line:
            try:
                stats.avg_impact = float(line.split(":")[-1].strip())
            except: pass
        elif "Regulatory Risk Flags:" in line:
            try:
                stats.regulatory_risk_flags = int(line.split(":")[-1].strip())
            except: pass
        elif "Earnings Risk Flags:" in line:
            try:
                stats.earnings_risk_flags = int(line.split(":")[-1].strip())
            except: pass
        elif "Credit Risk Flags:" in line:
            try:
                stats.credit_risk_flags = int(line.split(":")[-1].strip())
            except: pass
            
    return stats


def parse_symbol_mappings_section(section_text: str) -> List[SymbolStats]:
    """Parse the 'Symbol Mappings' section into SymbolStats objects."""
    import re
    stats = []
    
    # Format: "  005930: 5 articles (avg score: 0.580)"
    pattern = re.compile(r"^\s*(\w+):\s+(\d+)\s+articles\s+\(avg score:\s+([0-9.]+)\)")
    
    for line in section_text.splitlines():
        match = pattern.match(line)
        if match:
            stats.append(SymbolStats(
                symbol=match.group(1),
                article_count=int(match.group(2)),
                avg_score=float(match.group(3))
            ))
            
    return stats


def parse_recommendations_section(section_text: str) -> List[Recommendation]:
    """Parse the 'Recent Recommendations' section into Recommendation objects."""
    import re
    import ast
    from datetime import datetime
    from .models import RecommendationStatus
    
    recs = []
    current_rec = {}
    
    # Format:
    # 1. 035420 - ACTIVE
    #    Created: ...
    #    Sentiment: ... | Impact: ... | Composite: ...
    #    Risks: {...}
    #    Reason: ...
    
    lines = section_text.splitlines()
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
            
        # Match "1. SYMBOL - STATUS"
        match = re.match(r"^(\d+)\.\s+(\w+)\s+-\s+(\w+)$", line)
        if match:
            if current_rec:
                recs.append(Recommendation(
                    symbol=current_rec.get('symbol', ''),
                    status=RecommendationStatus(current_rec.get('status', 'UNKNOWN')),
                    created_at=current_rec.get('created_at', datetime.now()),
                    sentiment=current_rec.get('sentiment', 0.0),
                    impact=current_rec.get('impact', 0.0),
                    composite=current_rec.get('composite', 0.0),
                    risk_ratios=current_rec.get('risk_ratios', {}),
                    reason=current_rec.get('reason', '')
                ))
            
            current_rec = {
                'symbol': match.group(2),
                'status': match.group(3)
            }
            continue
            
        if not current_rec:
            continue
            
        if line.startswith("Created:"):
            dt_str = line.replace("Created:", "").strip()
            try:
                current_rec['created_at'] = datetime.fromisoformat(dt_str)
            except:
                current_rec['created_at'] = datetime.now()
                
        elif line.startswith("Sentiment:"):
            # Sentiment: +1.000 | Impact: 0.200 | Composite: 0.680
            parts = line.split("|")
            for part in parts:
                if "Sentiment:" in part:
                    try:
                        current_rec['sentiment'] = float(part.split(":")[-1].strip())
                    except: pass
                elif "Impact:" in part:
                    try:
                        current_rec['impact'] = float(part.split(":")[-1].strip())
                    except: pass
                elif "Composite:" in part:
                    try:
                        current_rec['composite'] = float(part.split(":")[-1].strip())
                    except: pass
                    
        elif line.startswith("Risks:"):
            dict_str = line.replace("Risks:", "").strip()
            try:
                current_rec['risk_ratios'] = ast.literal_eval(dict_str)
            except:
                current_rec['risk_ratios'] = {}
                
        elif line.startswith("Reason:"):
            current_rec['reason'] = line.replace("Reason:", "").strip()
            
    if current_rec:
        recs.append(Recommendation(
            symbol=current_rec.get('symbol', ''),
            status=RecommendationStatus(current_rec.get('status', 'UNKNOWN')),
            created_at=current_rec.get('created_at', datetime.now()),
            sentiment=current_rec.get('sentiment', 0.0),
            impact=current_rec.get('impact', 0.0),
            composite=current_rec.get('composite', 0.0),
            risk_ratios=current_rec.get('risk_ratios', {}),
            reason=current_rec.get('reason', '')
        ))
        
    return recs


def parse_regime_history_section(section_text: str) -> List[RegimeRecord]:
    """Parse the 'Regime History' section into RegimeRecord objects."""
    import re
    from datetime import datetime
    from .models import RegimeLabel
    
    records = []
    
    # Format:
    # 1. 2025-12-03 13:36:34.918289+09:00 - sideways (confidence: 60.00%)
    #    Description text
    
    lines = section_text.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
            
        # Match "1. TIMESTAMP - LABEL (confidence: X%)"
        match = re.match(r"^\d+\.\s+(.+?)\s+-\s+(\w+)\s+\(confidence:\s+([0-9.]+)%\)", line)
        if match:
            dt_str = match.group(1)
            label = match.group(2)
            conf = float(match.group(3))
            
            try:
                dt = datetime.fromisoformat(dt_str)
            except:
                dt = datetime.now()
                
            # Look ahead for description
            desc = ""
            if i + 1 < len(lines) and not lines[i+1].strip().startswith("="):
                desc = lines[i+1].strip()
                i += 1
                
            records.append(RegimeRecord(
                timestamp=dt,
                label=RegimeLabel(label) if label in [e.value for e in RegimeLabel] else RegimeLabel.UNKNOWN,
                confidence=conf / 100.0,  # Convert percentage to 0-1
                description=desc
            ))
        i += 1
        
    return records


def build_db_snapshot(raw_output: str, hours_window: int) -> DbSnapshot:
    """Build a DbSnapshot from the combined query_db.sh all output."""
    from datetime import datetime
    
    sections = split_query_all_output(raw_output)
    
    news = parse_news_section(sections["news_articles"])
    article_stats = parse_article_analysis_section(sections["article_analysis"])
    symbol_stats = parse_symbol_mappings_section(sections["symbol_mappings"])
    recommendations = parse_recommendations_section(sections["recommendations"])
    regime_history = parse_regime_history_section(sections["regime_history"])
    
    return DbSnapshot(
        generated_at=datetime.now(),
        hours_window=hours_window,
        news=news,
        article_stats=article_stats,
        symbol_stats=symbol_stats,
        recommendations=recommendations,
        regime_history=regime_history
    )
