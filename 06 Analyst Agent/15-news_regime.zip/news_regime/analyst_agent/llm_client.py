from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

from .config import LlmConfig
from .report_schema import AnalystCoreFindings


@dataclass
class LlmClient:
    """Thin wrapper around the OpenAI Agents SDK."""

    config: LlmConfig

    def generate_report_text(
        self,
        core_findings: AnalystCoreFindings,
        extra_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Generate a human-readable report using the LLM."""
        import os
        import json
        from datetime import datetime
        
        # Fallback stub function
        def _run_stub():
            regime_label = core_findings.current_regime.label.value if core_findings.current_regime else "Unknown"
            volatility = core_findings.volatility.level.value
            
            lines = []
            lines.append(f"# Market Analyst Report (STUB)")
            lines.append(f"**Regime**: {regime_label}")
            lines.append(f"**Volatility**: {volatility}")
            lines.append("")
            lines.append("## Executive Summary")
            lines.append(f"The market is currently in a {regime_label} state with {volatility} volatility.")
            if core_findings.regime_change.has_changed:
                lines.append(f"**ALERT**: Regime changed from {core_findings.regime_change.previous.label.value} to {regime_label}.")
            lines.append(f"Reason: {core_findings.volatility.reason}")
            lines.append("")
            lines.append("## Top Recommendations")
            if core_findings.top_recommendations:
                for rec in core_findings.top_recommendations:
                    lines.append(f"- **{rec.symbol}** ({rec.status.value}): Score {rec.composite:.2f}")
            else:
                lines.append("No active recommendations.")
            lines.append("")
            lines.append("## Focus Symbols")
            if core_findings.focus_symbols:
                for sym in core_findings.focus_symbols:
                    lines.append(f"- **{sym.symbol}**: {sym.article_count} articles, Sentiment {sym.avg_sentiment:.2f}")
            else:
                lines.append("No specific focus symbols identified.")
            lines.append("")
            lines.append("## Key News Drivers")
            if core_findings.key_news_drivers:
                for driver in core_findings.key_news_drivers:
                    lines.append(f"- {driver.title}")
                    lines.append(f"  *Impact*: {driver.impact_scope} ({driver.impact_direction})")
            else:
                lines.append("No significant market drivers detected.")
            return "\n".join(lines)

        # Check for API Key
        if not os.environ.get("OPENAI_API_KEY"):
            print("Warning: OPENAI_API_KEY not found. Using stub.")
            return _run_stub()

        try:
            from openai import OpenAI
            client = OpenAI(timeout=self.config.request_timeout)
            
            # Prepare context
            context = {
                "generated_at": datetime.now().isoformat(),
                "regime": {
                    "current": core_findings.current_regime.label.value if core_findings.current_regime else "unknown",
                    "confidence": core_findings.current_regime.confidence if core_findings.current_regime else 0.0,
                    "changed": core_findings.regime_change.has_changed,
                    "previous": core_findings.regime_change.previous.label.value if core_findings.regime_change.previous else None
                },
                "volatility": {
                    "level": core_findings.volatility.level.value,
                    "reason": core_findings.volatility.reason
                },
                "stats": {
                    "total_articles": core_findings.article_stats.total_articles if core_findings.article_stats else 0,
                    "avg_sentiment": core_findings.article_stats.avg_sentiment if core_findings.article_stats else 0.0,
                    "avg_impact": core_findings.article_stats.avg_impact if core_findings.article_stats else 0.0
                },
                "recommendations": [
                    {"symbol": r.symbol, "status": r.status.value, "score": r.composite, "reason": r.reason}
                    for r in core_findings.top_recommendations
                ],
                "focus_symbols": [
                    {"symbol": f.symbol, "count": f.article_count, "sentiment": f.avg_sentiment, "notes": f.notes}
                    for f in core_findings.focus_symbols
                ],
                "drivers": [
                    {"title": d.title, "scope": d.impact_scope, "direction": d.impact_direction, "reason": d.reason}
                    for d in core_findings.key_news_drivers
                ]
            }
            
            if extra_context:
                context.update(extra_context)
                
            system_prompt = (
                "You are an expert financial analyst agent. "
                "Your goal is to produce a concise, actionable market report based on the provided data. "
                "Focus on regime changes, volatility risks, and key trading opportunities. "
                "Use Markdown formatting. "
                "Sections: Executive Summary, Market Regime & Volatility, Top Recommendations, Focus Symbols, Key News Drivers."
            )
            
            user_prompt = f"Analyze the following market data and generate a report:\n\n{json.dumps(context, indent=2, ensure_ascii=False)}"
            
            response = client.chat.completions.create(
                model=self.config.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            print(f"Error calling OpenAI API: {e}. Falling back to stub.")
            return _run_stub()
