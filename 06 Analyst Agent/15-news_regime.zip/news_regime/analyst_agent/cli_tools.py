from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional


@dataclass
class CliCommandResult:
    """Result of executing a shell command."""

    command: List[str]
    stdout: str
    stderr: str
    exit_code: int
    started_at: datetime
    finished_at: datetime
    success: bool


def run_crawler_command(timeout_seconds: Optional[int] = None) -> CliCommandResult:
    """Execute ./run_crawler.sh and capture its result."""
    import subprocess
    from pathlib import Path
    
    # Assuming this file is in news_regime/analyst_agent/cli_tools.py
    # We want to run scripts in news_regime/
    base_dir = Path(__file__).resolve().parent.parent
    script_path = base_dir / "run_crawler.sh"
    
    cmd = [str(script_path)]
    start_time = datetime.now()
    
    # Inject PYTHONPATH to ensure news_regime package is found
    # We need to add the PARENT of news_regime to PYTHONPATH so that 'import news_regime' works
    import os
    env = os.environ.copy()
    parent_dir = str(base_dir.parent)
    if "PYTHONPATH" in env:
        env["PYTHONPATH"] = f"{parent_dir}:{env['PYTHONPATH']}"
    else:
        env["PYTHONPATH"] = parent_dir

    try:
        proc = subprocess.run(
            cmd,
            cwd=base_dir,
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False
        )
        stdout = proc.stdout
        stderr = proc.stderr
        exit_code = proc.returncode
    except subprocess.TimeoutExpired:
        stdout = ""
        stderr = "Command timed out"
        exit_code = 124  # Standard timeout exit code
    except Exception as e:
        stdout = ""
        stderr = str(e)
        exit_code = 1
        
    end_time = datetime.now()
    
    return CliCommandResult(
        command=cmd,
        stdout=stdout,
        stderr=stderr,
        exit_code=exit_code,
        started_at=start_time,
        finished_at=end_time,
        success=(exit_code == 0)
    )


def run_query_db_all(
    hours: int,
    limit: int,
    timeout_seconds: Optional[int] = None,
) -> CliCommandResult:
    """Execute ./query_db.sh all --hours H --limit N and capture its result."""
    import subprocess
    from pathlib import Path
    
    base_dir = Path(__file__).resolve().parent.parent
    script_path = base_dir / "query_db.sh"
    
    cmd = [str(script_path), "all", "--hours", str(hours), "--limit", str(limit)]
    start_time = datetime.now()
    
    try:
        proc = subprocess.run(
            cmd,
            cwd=base_dir,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False
        )
        stdout = proc.stdout
        stderr = proc.stderr
        exit_code = proc.returncode
    except subprocess.TimeoutExpired:
        stdout = ""
        stderr = "Command timed out"
        exit_code = 124
    except Exception as e:
        stdout = ""
        stderr = str(e)
        exit_code = 1
        
    end_time = datetime.now()
    
    return CliCommandResult(
        command=cmd,
        stdout=stdout,
        stderr=stderr,
        exit_code=exit_code,
        started_at=start_time,
        finished_at=end_time,
        success=(exit_code == 0)
    )
