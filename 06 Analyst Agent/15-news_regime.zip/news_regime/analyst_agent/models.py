from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional


class RecommendationStatus(str, Enum):
    """Possible statuses for a recommendation entry."""

    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    HOLD = "HOLD"
    UNKNOWN = "UNKNOWN"


class RegimeLabel(str, Enum):
    """Discrete labels describing the market regime."""

    RISK_ON = "risk_on"
    RISK_OFF = "risk_off"
    SIDEWAYS = "sideways"
    UNKNOWN = "unknown"


@dataclass
class NewsArticle:
    """Represents a single news article entry from the CLI output."""

    index: int
    title: str
    publisher: str
    category: str
    crawled_at: datetime
    url: str
    summary_raw: str
    summary_clean: Optional[str] = None


@dataclass
class ArticleStats:
    """Aggregated statistics over analyzed articles."""

    total_articles: int
    avg_sentiment: float
    avg_impact: float
    regulatory_risk_flags: int
    earnings_risk_flags: int
    credit_risk_flags: int


@dataclass
class SymbolStats:
    """Per-symbol statistics derived from the symbol mappings section."""

    symbol: str
    article_count: int
    avg_score: float


@dataclass
class Recommendation:
    """Represents a trading recommendation record."""

    symbol: str
    status: RecommendationStatus
    created_at: datetime
    sentiment: float
    impact: float
    composite: float
    risk_ratios: Dict[str, float] = field(default_factory=dict)
    reason: str = ""


@dataclass
class RegimeRecord:
    """Historical record of a market regime classification."""

    timestamp: datetime
    label: RegimeLabel
    confidence: float
    description: str


@dataclass
class DbSnapshot:
    """Full snapshot of the database view at a given time."""

    generated_at: datetime
    hours_window: int
    news: List[NewsArticle] = field(default_factory=list)
    article_stats: Optional[ArticleStats] = None
    symbol_stats: List[SymbolStats] = field(default_factory=list)
    recommendations: List[Recommendation] = field(default_factory=list)
    regime_history: List[RegimeRecord] = field(default_factory=list)
