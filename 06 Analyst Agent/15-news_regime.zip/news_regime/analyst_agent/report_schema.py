from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from .config import AnalystAgentConfig
from .models import ArticleStats, DbSnapshot, Recommendation, RegimeRecord


class VolatilityLevel(str, Enum):
    """Levels of market volatility as judged by analysis logic."""

    NORMAL = "NORMAL"
    WATCH = "WATCH"
    CAUTION = "CAUTION"
    SPIKE = "SPIKE"


@dataclass
class RegimeChange:
    """Summary of most recent regime change (if any)."""

    has_changed: bool
    previous: Optional[RegimeRecord]
    current: Optional[RegimeRecord]
    change_direction: Optional[str]


@dataclass
class VolatilityAssessment:
    """Assessment of volatility level and its key drivers."""

    level: VolatilityLevel
    reason: str
    key_drivers: List[str] = field(default_factory=list)


@dataclass
class FocusSymbol:
    """Symbol with concentrated news/sentiment activity."""

    symbol: str
    article_count: int
    avg_sentiment: float
    is_recommended: bool
    notes: str = ""


@dataclass
class KeyNewsDriver:
    """News item that is considered a key driver for the market."""

    title: str
    summary: str
    impact_direction: str
    impact_scope: str
    reason: str


@dataclass
class AnalystCoreFindings:
    """Core structured findings produced by analysis_logic."""

    current_regime: Optional[RegimeRecord]
    regime_change: RegimeChange
    volatility: VolatilityAssessment
    top_recommendations: List[Recommendation]
    focus_symbols: List[FocusSymbol]
    key_news_drivers: List[KeyNewsDriver]
    article_stats: Optional[ArticleStats]
    raw_snapshot: DbSnapshot


@dataclass
class AnalystReport:
    """Final report object produced by the Analyst Agent."""

    generated_at: datetime
    config: AnalystAgentConfig
    core_findings: AnalystCoreFindings
    formatted_text: str
    summary_header: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
