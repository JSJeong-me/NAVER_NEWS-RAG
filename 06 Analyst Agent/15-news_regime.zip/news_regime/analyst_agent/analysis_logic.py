from __future__ import annotations

from typing import List

from .config import AnalystAgentConfig
from .models import ArticleStats, DbSnapshot, Recommendation, RegimeRecord, SymbolStats
from .report_schema import (
    AnalystCoreFindings,
    FocusSymbol,
    KeyNewsDriver,
    RegimeChange,
    VolatilityAssessment,
)


def analyze_regime_change(
    regime_history: List[RegimeRecord],
    window_size: int,
) -> RegimeChange:
    """Analyze whether a regime change has recently occurred."""
    if not regime_history:
        return RegimeChange(False, None, None, None)
        
    # Sort by timestamp descending (newest first)
    sorted_history = sorted(regime_history, key=lambda x: x.timestamp, reverse=True)
    
    current = sorted_history[0]
    previous = None
    
    # Look for the first record that has a different label
    for record in sorted_history[1:window_size+1]:
        if record.label != current.label:
            previous = record
            break
            
    if previous:
        return RegimeChange(
            has_changed=True,
            previous=previous,
            current=current,
            change_direction=f"{previous.label.value}_to_{current.label.value}"
        )
        
    return RegimeChange(False, None, current, None)


def assess_volatility(
    article_stats: ArticleStats,
    regime_history: List[RegimeRecord],
    config: AnalystAgentConfig,
) -> VolatilityAssessment:
    """Assess volatility level using article stats and regime history."""
    from .report_schema import VolatilityLevel
    
    reasons = []
    drivers = []
    level = VolatilityLevel.NORMAL
    
    # Check 1: Impact Score
    if article_stats.avg_impact >= config.volatility_thresholds.impact_spike_min:
        level = VolatilityLevel.SPIKE
        reasons.append(f"High average news impact ({article_stats.avg_impact:.2f})")
    elif article_stats.avg_impact >= config.volatility_thresholds.impact_caution_min:
        level = VolatilityLevel.CAUTION
        reasons.append(f"Elevated news impact ({article_stats.avg_impact:.2f})")
        
    # Check 2: Risk Flags
    total = article_stats.total_articles or 1
    risk_ratio = (article_stats.regulatory_risk_flags + 
                  article_stats.earnings_risk_flags + 
                  article_stats.credit_risk_flags) / total
                  
    if risk_ratio >= config.volatility_thresholds.risk_flag_spike_ratio:
        level = VolatilityLevel.SPIKE if level != VolatilityLevel.SPIKE else level
        reasons.append(f"High risk flag ratio ({risk_ratio:.2%})")
    elif risk_ratio >= config.volatility_thresholds.risk_flag_caution_ratio:
        level = VolatilityLevel.CAUTION if level not in [VolatilityLevel.SPIKE, VolatilityLevel.CAUTION] else level
        reasons.append(f"Elevated risk flag ratio ({risk_ratio:.2%})")
        
    # Check 3: Regime Change
    regime_change = analyze_regime_change(regime_history, config.regime_window_size)
    if regime_change.has_changed:
        level = VolatilityLevel.WATCH if level == VolatilityLevel.NORMAL else level
        reasons.append(f"Recent regime change: {regime_change.change_direction}")
        
    if level == VolatilityLevel.NORMAL:
        reasons.append("Metrics within normal ranges")
        
    return VolatilityAssessment(
        level=level,
        reason="; ".join(reasons),
        key_drivers=drivers  # Drivers will be populated by extract_key_news_drivers
    )


def select_top_recommendations(
    recommendations: List[Recommendation],
    max_count: int,
) -> List[Recommendation]:
    """Select top N recommendations based on composite score."""
    from .models import RecommendationStatus
    
    # Filter for ACTIVE only
    active_recs = [r for r in recommendations if r.status == RecommendationStatus.ACTIVE]
    
    # Sort by composite score descending
    sorted_recs = sorted(active_recs, key=lambda r: r.composite, reverse=True)
    
    return sorted_recs[:max_count]


def identify_focus_symbols(
    symbol_stats: List[SymbolStats],
    recommendations: List[Recommendation],
    max_count: int,
) -> List[FocusSymbol]:
    """Identify symbols with concentrated news/sentiment."""
    # Build map of recommended symbols
    rec_map = {r.symbol: r for r in recommendations}
    
    # Sort by article count descending, then avg_score
    sorted_stats = sorted(symbol_stats, key=lambda s: (s.article_count, abs(s.avg_score)), reverse=True)
    
    focus_symbols = []
    for stat in sorted_stats[:max_count]:
        is_rec = stat.symbol in rec_map
        rec_status = rec_map[stat.symbol].status.value if is_rec else "None"
        
        notes = f"High activity ({stat.article_count} articles). "
        if is_rec:
            notes += f"Recommended ({rec_status})."
            
        focus_symbols.append(FocusSymbol(
            symbol=stat.symbol,
            article_count=stat.article_count,
            avg_sentiment=stat.avg_score,
            is_recommended=is_rec,
            notes=notes
        ))
        
    return focus_symbols


def extract_key_news_drivers(
    news,
    article_stats: ArticleStats,
    regime_history: List[RegimeRecord],
    max_count: int,
) -> List[KeyNewsDriver]:
    """Extract key news drivers from the full news list."""
    # Heuristic keywords
    market_keywords = ["코스피", "코스닥", "환율", "금리", "FOMC", "연준", "GDP", "수출"]
    sector_keywords = ["반도체", "2차전지", "바이오", "자동차", "금융", "AI"]
    risk_keywords = ["규제", "과징금", "소송", "압수수색", "적자", "급락", "폭락"]
    
    drivers = []
    
    # Simple scoring for "driver-ness"
    # We don't have impact scores per article in the NewsArticle model (only in DB),
    # so we rely on keywords and summary text.
    
    for article in news:
        score = 0
        impact_scope = "stock"
        impact_direction = "mixed"
        reason = "General news"
        
        text = (article.title + " " + article.summary_raw).lower()
        
        # Check market scope
        if any(k.lower() in text for k in market_keywords):
            score += 3
            impact_scope = "market"
            reason = "Market-wide macro factor"
            
        # Check sector scope
        elif any(k.lower() in text for k in sector_keywords):
            score += 2
            impact_scope = "sector"
            reason = "Key sector news"
            
        # Check risks
        if any(k.lower() in text for k in risk_keywords):
            score += 2
            impact_direction = "negative"
            reason += ", Risk factor detected"
            
        # Add to candidates if score is high enough
        if score >= 2:
            drivers.append(KeyNewsDriver(
                title=article.title,
                summary=article.summary_raw[:100] + "...",
                impact_direction=impact_direction,
                impact_scope=impact_scope,
                reason=reason
            ))
            
    # Return top N
    return drivers[:max_count]


def build_core_findings(
    snapshot: DbSnapshot,
    config: AnalystAgentConfig,
) -> AnalystCoreFindings:
    """Build AnalystCoreFindings from a DbSnapshot and config."""
    
    # 1. Regime Analysis
    regime_change = analyze_regime_change(snapshot.regime_history, config.regime_window_size)
    current_regime = regime_change.current
    
    # 2. Volatility Assessment
    volatility = assess_volatility(
        snapshot.article_stats or ArticleStats(0,0,0,0,0,0), 
        snapshot.regime_history, 
        config
    )
    
    # 3. Recommendations
    top_recs = select_top_recommendations(snapshot.recommendations, 5)
    
    # 4. Focus Symbols
    focus_symbols = identify_focus_symbols(snapshot.symbol_stats, snapshot.recommendations, 5)
    
    # 5. Key Drivers
    key_drivers = extract_key_news_drivers(
        snapshot.news, 
        snapshot.article_stats, 
        snapshot.regime_history, 
        5
    )
    
    # Update volatility drivers
    volatility.key_drivers = [d.title for d in key_drivers[:3]]
    
    return AnalystCoreFindings(
        current_regime=current_regime,
        regime_change=regime_change,
        volatility=volatility,
        top_recommendations=top_recs,
        focus_symbols=focus_symbols,
        key_news_drivers=key_drivers,
        article_stats=snapshot.article_stats,
        raw_snapshot=snapshot
    )
