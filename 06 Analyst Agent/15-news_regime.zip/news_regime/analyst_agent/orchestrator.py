from __future__ import annotations

from pathlib import Path
from typing import Dict

from .analysis_logic import build_core_findings
from .cli_tools import CliCommandResult, run_crawler_command, run_query_db_all
from .config import AnalystAgentConfig
from .llm_client import LlmClient
from .parse_query_output import build_db_snapshot
from .report_generator import generate_analyst_report
from .report_schema import AnalystReport


def run_analyst_cycle_once(config: AnalystAgentConfig) -> AnalystReport:
    """Run a single analysis cycle and return the resulting report."""
    cli_results = {}
    
    # 1. Run Crawler (Optional)
    if config.run_crawler_before_analysis:
        print("Running crawler...")
        crawler_res = run_crawler_command(timeout_seconds=300)
        cli_results["crawler"] = crawler_res
        if not crawler_res.success:
            print(f"Crawler failed: {crawler_res.stderr}")
            # We continue even if crawler fails, using existing DB data
            
    # 2. Query Database
    print("Querying database...")
    query_res = run_query_db_all(
        hours=config.hours_window,
        limit=config.news_limit,
        timeout_seconds=60
    )
    cli_results["query_db"] = query_res
    
    if not query_res.success:
        raise RuntimeError(f"Database query failed: {query_res.stderr}")
        
    # 3. Parse Output
    print("Parsing data...")
    snapshot = build_db_snapshot(query_res.stdout, config.hours_window)
    
    # 4. Analyze
    print("Analyzing market data...")
    core_findings = build_core_findings(snapshot, config)
    
    # 5. Generate Report
    print("Generating report...")
    llm_client = LlmClient(config.llm)
    report = generate_analyst_report(core_findings, config, llm_client)
    
    # 6. Log Cycle
    log_analyst_cycle(report, cli_results, config.log_dir)
    
    return report


def save_analyst_report(
    report: AnalystReport,
    output_dir: str | Path | None = None,
) -> Path:
    """Persist the report to disk and return the resulting file path."""
    if output_dir is None:
        output_dir = Path("./reports")
    else:
        output_dir = Path(output_dir)
        
    output_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = report.generated_at.strftime("%Y%m%d_%H%M%S")
    regime = report.core_findings.current_regime.label.value if report.core_findings.current_regime else "unknown"
    filename = f"analyst_report_{timestamp}_{regime}.md"
    
    file_path = output_dir / filename
    
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(report.formatted_text)
        
    print(f"Report saved to: {file_path}")
    return file_path


def log_analyst_cycle(
    report: AnalystReport,
    cli_results: Dict[str, CliCommandResult],
    log_dir: str | Path | None = None,
) -> None:
    """Log summary information for an analysis cycle."""
    import logging
    
    if log_dir is None:
        log_dir = Path("./logs")
    else:
        log_dir = Path(log_dir)
        
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "analyst_agent.log"
    
    # Configure logging
    logger = logging.getLogger("analyst_agent")
    logger.setLevel(logging.INFO)
    
    # File handler
    fh = logging.FileHandler(log_file)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    
    # Construct log message
    regime = report.core_findings.current_regime
    regime_str = f"{regime.label.value} ({regime.confidence:.0%})" if regime else "Unknown"
    volatility = report.core_findings.volatility.level.value
    
    top_syms = [r.symbol for r in report.core_findings.top_recommendations[:3]]
    
    crawler_status = "SKIP"
    if "crawler" in cli_results:
        crawler_status = "OK" if cli_results["crawler"].success else "FAIL"
        
    query_status = "OK" if cli_results["query_db"].success else "FAIL"
    
    msg = (
        f"Cycle Complete | Regime: {regime_str} | Volatility: {volatility} | "
        f"Recs: {top_syms} | Crawler: {crawler_status} | Query: {query_status}"
    )
    
    logger.info(msg)
    
    # Clean up handlers to avoid duplication
    logger.removeHandler(fh)
    fh.close()
