from dataclasses import dataclass, field
from typing import Optional


@dataclass
class VolatilityThresholdConfig:
    """Thresholds and heuristics used to classify volatility levels.

    All numeric values here are domain-specific and should be tuned
    experimentally. They are intentionally simple to keep the first
    implementation easy to reason about.
    """

    impact_normal_max: float = 0.1
    impact_caution_min: float = 0.15
    impact_spike_min: float = 0.3
    risk_flag_caution_ratio: float = 0.1
    risk_flag_spike_ratio: float = 0.3


@dataclass
class LlmConfig:
    """Configuration for the LLM / Agents SDK integration."""

    model: str = "gpt-4o-mini"
    temperature: float = 0.3
    max_tokens: int = 2048
    request_timeout: float = 30.0
    response_format: Optional[str] = "text"


@dataclass
class AnalystAgentConfig:
    """Top-level configuration for the Analyst Agent runtime."""

    hours_window: int = 24
    news_limit: int = 50
    run_crawler_before_analysis: bool = True
    report_output_dir: str = "./reports"
    log_dir: str = "./logs"
    regime_window_size: int = 3
    volatility_thresholds: VolatilityThresholdConfig = field(default_factory=VolatilityThresholdConfig)
    llm: LlmConfig = field(default_factory=LlmConfig)
    scheduler_mode: str = "once"
    env_name: str = "prod"


def load_analyst_agent_config() -> AnalystAgentConfig:
    """Load configuration for the Analyst Agent.

    Loads from (in order of precedence):
    1. Environment variables (ANALYST_*)
    2. YAML config file (./config/analyst_agent.yaml)
    3. Defaults
    """
    import os
    import logging
    from pathlib import Path

    # Start with defaults
    config = AnalystAgentConfig()
    
    # Try loading from YAML
    config_path = Path("./config/analyst_agent.yaml")
    if config_path.exists():
        try:
            import yaml
            with open(config_path, "r") as f:
                data = yaml.safe_load(f)
                if data:
                    # Update top-level fields
                    for key, value in data.items():
                        if hasattr(config, key) and key not in ["volatility_thresholds", "llm"]:
                            setattr(config, key, value)
                    
                    # Update nested configs
                    if "volatility_thresholds" in data:
                        for k, v in data["volatility_thresholds"].items():
                            if hasattr(config.volatility_thresholds, k):
                                setattr(config.volatility_thresholds, k, v)
                                
                    if "llm" in data:
                        for k, v in data["llm"].items():
                            if hasattr(config.llm, k):
                                setattr(config.llm, k, v)
        except ImportError:
            logging.warning("PyYAML not installed, skipping config file loading")
        except Exception as e:
            logging.warning(f"Failed to load config file: {e}")

    # Override with Environment Variables
    # Format: ANALYST_HOURS_WINDOW, ANALYST_LLM_MODEL, etc.
    
    if os.environ.get("ANALYST_HOURS_WINDOW"):
        config.hours_window = int(os.environ["ANALYST_HOURS_WINDOW"])
        
    if os.environ.get("ANALYST_NEWS_LIMIT"):
        config.news_limit = int(os.environ["ANALYST_NEWS_LIMIT"])
        
    if os.environ.get("ANALYST_RUN_CRAWLER"):
        config.run_crawler_before_analysis = os.environ["ANALYST_RUN_CRAWLER"].lower() == "true"
        
    if os.environ.get("ANALYST_ENV"):
        config.env_name = os.environ["ANALYST_ENV"]

    # LLM overrides
    if os.environ.get("ANALYST_LLM_MODEL"):
        config.llm.model = os.environ["ANALYST_LLM_MODEL"]
        
    return config
