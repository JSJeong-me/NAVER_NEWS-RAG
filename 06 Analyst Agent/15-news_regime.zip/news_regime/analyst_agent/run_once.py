from __future__ import annotations

import sys

from .config import load_analyst_agent_config
from .orchestrator import run_analyst_cycle_once, save_analyst_report


def main(argv: list[str] | None = None) -> int:
    """Entry point for running a single Analyst Agent cycle."""
    import argparse
    import sys
    
    if argv is None:
        argv = sys.argv[1:]
        
    parser = argparse.ArgumentParser(description="Run Analyst Agent Cycle")
    parser.add_argument("--hours", type=int, help="Override analysis window (hours)")
    parser.add_argument("--no-crawl", action="store_true", help="Skip crawler execution")
    parser.add_argument("--output-dir", type=str, help="Override report output directory")
    
    args = parser.parse_args(argv)

    # Load config and apply overrides
    config = load_analyst_agent_config()
    
    if args.hours:
        config.hours_window = args.hours
    if args.no_crawl:
        config.run_crawler_before_analysis = False
    if args.output_dir:
        config.report_output_dir = args.output_dir
        
    try:
        report = run_analyst_cycle_once(config)
        
        # Print report to stdout
        print("\n" + "="*80)
        print(report.formatted_text)
        print("="*80 + "\n")
        
        save_analyst_report(report, output_dir=config.report_output_dir)
        return 0
        
    except Exception as e:
        print(f"Error running analyst cycle: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
