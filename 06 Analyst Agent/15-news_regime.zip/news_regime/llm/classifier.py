
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

from .client import LlmClient, LlmMessage, LlmResult
from .prompts import ARTICLE_CLASSIFICATION_PROMPT, PromptTemplate


@dataclass
class ArticleClassification:
    headline_normalized: str
    primary_tickers: List[str]
    market_regime: str
    market_regime_confidence: float
    trade_action: str
    trade_horizon: str
    sizing_hint: str
    bullish_factors: List[str]
    bearish_factors: List[str]
    risk_overrides: Dict[str, bool]
    overall_confidence: float
    raw_dict: Dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, data: Dict[str, Any]) -> "ArticleClassification":
        return cls(
            headline_normalized=data.get("headline_normalized", ""),
            primary_tickers=data.get("primary_tickers", []) or [],
            market_regime=data.get("market_regime", "unknown"),
            market_regime_confidence=float(data.get("market_regime_confidence", 0.0) or 0.0),
            trade_action=data.get("trade_action", "IGNORE"),
            trade_horizon=data.get("trade_horizon", "unknown"),
            sizing_hint=data.get("sizing_hint", "small"),
            bullish_factors=data.get("bullish_factors", []) or [],
            bearish_factors=data.get("bearish_factors", []) or [],
            risk_overrides=data.get("risk_overrides", {}) or {},
            overall_confidence=float(data.get("overall_confidence", 0.0) or 0.0),
            raw_dict=data,
        )


class NewsClassifier:
    """LLM-based article-level trade/regime classifier."""

    def __init__(
        self,
        llm_client: LlmClient,
        template: PromptTemplate = ARTICLE_CLASSIFICATION_PROMPT,
    ) -> None:
        self.llm = llm_client
        self.template = template

    def classify_article(
        self,
        headline: str,
        body: str,
    ) -> Tuple[ArticleClassification, LlmResult]:
        user_prompt = self.template.user.format(
            headline=headline.strip(),
            body=body.strip(),
        )
        messages = [
            LlmMessage(role="system", content=self.template.system),
            LlmMessage(role="user", content=user_prompt),
        ]
        result = self.llm.generate(messages, response_format=self.template.response_format)
        if result.parsed_json is None or not isinstance(result.parsed_json, dict):
            raise ValueError("NewsClassifier: invalid JSON from LLM")
        classification = ArticleClassification.from_payload(result.parsed_json)
        return classification, result
