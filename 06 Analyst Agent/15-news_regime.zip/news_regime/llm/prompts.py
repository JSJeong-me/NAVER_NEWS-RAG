
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict


@dataclass(frozen=True)
class PromptTemplate:
    id: str
    description: str
    system: str
    user: str
    response_format: Dict[str, Any] | None = None


ARTICLE_SUMMARY_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "headline_normalized": {"type": "string"},
        "summary_ko": {"type": "string"},
        "summary_en": {"type": "string"},
        "sentiment": {
            "type": "string",
            "enum": ["very_negative", "negative", "neutral", "positive", "very_positive"],
        },
        "impact_direction": {
            "type": "string",
            "enum": ["bullish", "bearish", "mixed", "none", "unknown"],
        },
        "impact_strength": {
            "type": "string",
            "enum": ["low", "medium", "high"],
        },
        "regime_hint": {
            "type": "string",
            "enum": ["risk_on", "risk_off", "sideways", "volatile", "unknown"],
        },
        "risk_flags": {
            "type": "object",
            "properties": {
                "regulation": {"type": "boolean"},
                "macro": {"type": "boolean"},
                "fx": {"type": "boolean"},
                "credit": {"type": "boolean"},
                "liquidity": {"type": "boolean"},
                "geopolitics": {"type": "boolean"},
                "earnings": {"type": "boolean"},
                "valuation": {"type": "boolean"},
            },
            "required": [
                "regulation", "macro", "fx", "credit",
                "liquidity", "geopolitics", "earnings", "valuation",
            ],
            "additionalProperties": False,
        },
        "theme_tags": {"type": "array", "items": {"type": "string"}},
        "mentions_tickers": {"type": "array", "items": {"type": "string"}},
        "is_buy_candidate": {"type": "boolean"},
        "buy_candidate_reason": {"type": "string"},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
    },
    "required": [
        "headline_normalized",
        "summary_ko",
        "sentiment",
        "impact_direction",
        "impact_strength",
        "risk_flags",
        "is_buy_candidate",
        "confidence",
    ],
    "additionalProperties": False,
}


ARTICLE_SUMMARY_PROMPT = PromptTemplate(
    id="news.article_summary.v1",
    description="Naver Finance news article summary + signals",
    system=(
        "You are a professional Korean equity research analyst.\n"
        "You summarize Korean stock market news and extract structured signals for trading.\n"
        "Answer ONLY with a single JSON object following the given schema."
    ),
    user=(
        "[Headline]\n{headline}\n\n"
        "[Body]\n{body}\n\n"
        "Return JSON only."
    ),
    response_format={
        "type": "json_schema",
        "json_schema": {
            "name": "news_article_summary",
            "strict": True,
            "schema": ARTICLE_SUMMARY_SCHEMA,
        },
    },
)


ARTICLE_CLASSIFICATION_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "properties": {
        "headline_normalized": {"type": "string"},
        "primary_tickers": {"type": "array", "items": {"type": "string"}},
        "market_regime": {
            "type": "string",
            "enum": ["risk_on", "risk_off", "sideways", "crash", "euphoric", "unknown"],
        },
        "market_regime_confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
        "trade_action": {
            "type": "string",
            "enum": ["BUY", "ADD", "HOLD", "REDUCE", "EXIT", "AVOID", "IGNORE"],
        },
        "trade_horizon": {
            "type": "string",
            "enum": ["intraday", "swing", "position", "unknown"],
        },
        "sizing_hint": {
            "type": "string",
            "enum": ["small", "normal", "large", "avoid"],
        },
        "bullish_factors": {"type": "array", "items": {"type": "string"}},
        "bearish_factors": {"type": "array", "items": {"type": "string"}},
        "risk_overrides": {
            "type": "object",
            "properties": {
                "block_entry": {"type": "boolean"},
                "reduce_leverage": {"type": "boolean"},
                "block_short": {"type": "boolean"},
            },
            "required": ["block_entry", "reduce_leverage", "block_short"],
            "additionalProperties": False,
        },
        "overall_confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
    },
    "required": [
        "headline_normalized",
        "market_regime",
        "trade_action",
        "overall_confidence",
    ],
    "additionalProperties": False,
}


ARTICLE_CLASSIFICATION_PROMPT = PromptTemplate(
    id="news.article_classification.v1",
    description="Naver Finance article-level trade/regime classification",
    system=(
        "You are a Korean equity news classifier for an automated trading system.\n"
        "Infer trade_action, regime, and risk overrides from each article.\n"
        "Return JSON only, no extra explanation."
    ),
    user=(
        "[Headline]\n{headline}\n\n"
        "[Body]\n{body}\n\n"
        "Return JSON only."
    ),
    response_format={
        "type": "json_schema",
        "json_schema": {
            "name": "news_article_classification",
            "strict": True,
            "schema": ARTICLE_CLASSIFICATION_SCHEMA,
        },
    },
)
