
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

from .client import LlmClient, LlmMessage, LlmResult
from .prompts import ARTICLE_SUMMARY_PROMPT, PromptTemplate


@dataclass
class NewsSummary:
    headline_normalized: str
    summary_ko: str
    summary_en: str
    sentiment: str
    impact_direction: str
    impact_strength: str
    regime_hint: str
    risk_flags: Dict[str, bool]
    theme_tags: List[str] = field(default_factory=list)
    mentions_tickers: List[str] = field(default_factory=list)
    is_buy_candidate: bool = False
    buy_candidate_reason: str = ""
    confidence: float = 0.0
    raw_dict: Dict[str, Any] | None = None

    @classmethod
    def from_payload(cls, data: Dict[str, Any]) -> "NewsSummary":
        return cls(
            headline_normalized=data.get("headline_normalized", ""),
            summary_ko=data.get("summary_ko", ""),
            summary_en=data.get("summary_en", ""),
            sentiment=data.get("sentiment", "neutral"),
            impact_direction=data.get("impact_direction", "unknown"),
            impact_strength=data.get("impact_strength", "low"),
            regime_hint=data.get("regime_hint", "unknown"),
            risk_flags=data.get("risk_flags", {}) or {},
            theme_tags=data.get("theme_tags", []) or [],
            mentions_tickers=data.get("mentions_tickers", []) or [],
            is_buy_candidate=bool(data.get("is_buy_candidate", False)),
            buy_candidate_reason=data.get("buy_candidate_reason", ""),
            confidence=float(data.get("confidence", 0.0) or 0.0),
            raw_dict=data,
        )


class NewsSummarizer:
    """LLM-based Naver Finance article summarizer."""

    def __init__(
        self,
        llm_client: LlmClient,
        template: PromptTemplate = ARTICLE_SUMMARY_PROMPT,
    ) -> None:
        self.llm = llm_client
        self.template = template

    def summarize_article(
        self,
        headline: str,
        body: str,
    ) -> Tuple[NewsSummary, LlmResult]:
        user_prompt = self.template.user.format(
            headline=headline.strip(),
            body=body.strip(),
        )
        messages = [
            LlmMessage(role="system", content=self.template.system),
            LlmMessage(role="user", content=user_prompt),
        ]
        result = self.llm.generate(messages, response_format=self.template.response_format)
        if result.parsed_json is None or not isinstance(result.parsed_json, dict):
            raise ValueError("NewsSummarizer: invalid JSON from LLM")
        summary = NewsSummary.from_payload(result.parsed_json)
        return summary, result
