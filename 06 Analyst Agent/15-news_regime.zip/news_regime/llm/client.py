
from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Sequence

from openai import OpenAI
from openai import APIError, APIConnectionError, APIStatusError  # type: ignore

logger = logging.getLogger(__name__)


@dataclass
class LlmClientConfig:
    """Config for LlmClient, separate from global AppConfig for simplicity."""
    model_name: str = "gpt-4o-mini"
    temperature: float = 0.2
    max_tokens: int = 800
    request_timeout: float = 15.0


@dataclass
class LlmMessage:
    role: str  # "system" | "user" | "assistant"
    content: str


@dataclass
class LlmResult:
    raw_text: str
    parsed_json: Any | None
    usage: Dict[str, Any] | None
    request_id: Optional[str] = None
    raw_response: Any | None = None


class LlmClient:
    """Thin wrapper over OpenAI Chat Completions with JSON parsing helper."""

    def __init__(self, config: LlmClientConfig) -> None:
        self.config = config
        self._client = OpenAI(timeout=config.request_timeout)

    def generate(
        self,
        messages: Sequence[LlmMessage],
        response_format: Optional[Dict[str, Any]] = None,
    ) -> LlmResult:
        api_messages = [
            {"role": m.role, "content": m.content}
            for m in messages
        ]

        try:
            completion = self._client.chat.completions.create(
                model=self.config.model_name,
                messages=api_messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                response_format=response_format,
            )
        except (APIConnectionError, APIStatusError, APIError) as exc:  # type: ignore
            logger.exception("LLM call failed: %s", exc)
            raise

        choice = completion.choices[0]
        text = choice.message.content or ""

        usage = None
        if getattr(completion, "usage", None) is not None:
            try:
                usage = completion.usage.model_dump()  # type: ignore
            except Exception:
                usage = dict(completion.usage)  # type: ignore

        request_id = getattr(completion, "_request_id", None)
        parsed = self._try_parse_json(text)

        return LlmResult(
            raw_text=text,
            parsed_json=parsed,
            usage=usage,
            request_id=request_id,
            raw_response=completion,
        )

    def generate_batch(
        self,
        batch_messages: Sequence[Sequence[LlmMessage]],
        response_format: Optional[Dict[str, Any]] = None,
    ) -> List[LlmResult]:
        results: List[LlmResult] = []
        for msgs in batch_messages:
            results.append(self.generate(msgs, response_format=response_format))
        return results

    @staticmethod
    def _try_parse_json(text: str) -> Any | None:
        cleaned = text.strip()
        if cleaned.startswith("```"):
            lines = cleaned.splitlines()
            if len(lines) >= 3 and lines[0].startswith("```"):
                lines = lines[1:]
                if lines[-1].strip().startswith("```"):
                    lines = lines[:-1]
                cleaned = "\n".join(lines).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            logger.debug("Failed to parse JSON from LLM: %s", text)
            return None
