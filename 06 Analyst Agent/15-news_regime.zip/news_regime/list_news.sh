#!/bin/bash
# Wrapper script to run list_news.py with proper Python path

cd /home/ubuntu
python -c "import sys; sys.path.insert(0, '/home/ubuntu'); from news_regime.cli.list_news import main; main()"
