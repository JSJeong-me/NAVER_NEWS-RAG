#!/bin/bash
# Wrapper script to run query_db.py with proper Python path

cd /home/ubuntu
python -c "import sys; sys.path.insert(0, '/home/ubuntu'); from news_regime.cli.query_db import main; main()" "$@"
