
from datetime import datetime
from news_regime.parser.mainnews_parser import MainNewsParser

with open("mainnews.html", "r", encoding="utf-8") as f:
    html = f.read()

parser = MainNewsParser()
articles = parser.parse(html, datetime.now())

print(f"Found {len(articles)} articles")
for a in articles[:3]:
    print(f"- {a.title} ({a.publisher}) [{a.url}]")
