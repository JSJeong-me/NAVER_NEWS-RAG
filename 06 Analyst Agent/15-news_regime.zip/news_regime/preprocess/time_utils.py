
from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo


class TimeParser:
    """Parses Naver-style time strings into timezone-aware datetime."""

    def __init__(self, timezone: str) -> None:
        self.timezone = timezone

    def parse_published_time(self, raw_time_str: str) -> datetime:
        """Parse raw Naver time string like '2025.12.02 10:30'."""
        from datetime import datetime
        from zoneinfo import ZoneInfo
        
        # Try common Korean date formats
        formats = [
            "%Y.%m.%d %H:%M",
            "%Y-%m-%d %H:%M",
            "%Y.%m.%d",
            "%Y-%m-%d",
        ]
        
        for fmt in formats:
            try:
                naive_dt = datetime.strptime(raw_time_str.strip(), fmt)
                tz = ZoneInfo(self.timezone)
                return naive_dt.replace(tzinfo=tz)
            except ValueError:
                continue
        
        # If all fail, return current time
        return datetime.now(ZoneInfo(self.timezone))
