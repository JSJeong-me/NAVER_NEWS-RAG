
from __future__ import annotations


class TextNormalizer:
    """Basic HTML/text cleanup utilities."""

    def strip_html(self, html: str) -> str:
        """Remove tags and return plain text."""
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, 'lxml')
        return soup.get_text()

    def normalize_whitespace(self, text: str) -> str:
        """Normalize whitespace and linebreaks."""
        import re
        # Replace multiple spaces with single space
        text = re.sub(r' +', ' ', text)
        # Replace multiple newlines with double newline
        text = re.sub(r'\n\n+', '\n\n', text)
        # Remove leading/trailing whitespace
        return text.strip()

    def normalize_text(self, html_or_text: str) -> str:
        """Full pipeline for article body normalisation."""
        # First strip HTML if present
        text = self.strip_html(html_or_text)
        # Then normalize whitespace
        text = self.normalize_whitespace(text)
        return text
