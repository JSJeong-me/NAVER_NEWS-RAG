"""Common utilities (logging, time, exceptions)."""
