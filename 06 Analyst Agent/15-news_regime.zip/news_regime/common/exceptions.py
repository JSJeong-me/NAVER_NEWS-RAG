
class NewsRegimeError(Exception):
    """Base exception for the news_regime package."""


class CrawlError(NewsRegimeError):
    """Errors during crawling HTTP pages."""


class ParseError(NewsRegimeError):
    """Errors during HTML parsing."""


class AnalysisError(NewsRegimeError):
    """Errors during sentiment/risk/regime analysis."""
