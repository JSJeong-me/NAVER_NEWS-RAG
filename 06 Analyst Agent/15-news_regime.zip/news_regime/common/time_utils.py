
from __future__ import annotations
from datetime import datetime, timezone
from zoneinfo import ZoneInfo


def now_in_timezone(tz_name: str) -> datetime:
    """Return current time in given timezone."""
    tz = ZoneInfo(tz_name)
    return datetime.now(tz)
