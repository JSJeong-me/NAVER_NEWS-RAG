
import logging
from typing import Optional


def setup_logging(level: str = "INFO", name: Optional[str] = None) -> None:
    """Simple logging configuration helper.

    In a real system you may want to add rotating file handlers etc.
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        fmt = "[%(asctime)s] %(levelname)s %(name)s - %(message)s"
        handler.setFormatter(logging.Formatter(fmt))
        logger.addHandler(handler)
    logger.setLevel(level)
