
from __future__ import annotations
from dataclasses import dataclass


@dataclass
class DbConfig:
    """Database connection settings."""
    dsn: str
    echo: bool = False
    pool_size: int = 5
    timeout: float = 30.0


@dataclass
class CrawlConfig:
    """Crawling configuration for Naver Finance main news."""
    base_url: str
    mainnews_path: str = "/news/mainnews.naver"
    user_agent: str = "news_regime_crawler"
    request_timeout: float = 10.0
    max_retries: int = 3
    retry_backoff_sec: float = 1.0
    min_request_interval_sec: float = 0.5


@dataclass
class AnalysisConfig:
    """News sentiment/risk/recommendation thresholds."""
    sentiment_positive_threshold: float = 0.2
    sentiment_negative_threshold: float = -0.2
    min_articles_for_symbol: int = 1
    aggregation_window_hours: int = 24
    max_regulatory_risk_ratio_for_buy: float = 0.1
    min_impact_for_buy: float = 0.1


@dataclass
class RegimeConfig:
    """Market regime classification rules."""
    regime_window_hours: int = 24
    bullish_sentiment_threshold: float = 0.2
    bearish_sentiment_threshold: float = -0.2
    high_risk_ratio_threshold: float = 0.3
    volatility_impact_threshold: float = 0.5


@dataclass
class ArchiveConfig:
    """Archiving / retention configuration (e.g. 3 days)."""
    retention_days: int = 3
    archive_root_dir: str = "./archive"
    file_format: str = "parquet"
    batch_size: int = 1000


@dataclass
class LlmConfig:
    """LLM invocation settings (OpenAI, etc.)."""
    model_name: str = "gpt-4o-mini"
    temperature: float = 0.2
    max_tokens: int = 800
    request_timeout: float = 15.0

    use_for_article_summary: bool = True
    use_for_symbol_summary: bool = True
    use_for_regime_explanation: bool = True
    use_for_sentiment_risk: bool = False


@dataclass
class AppConfig:
    """Top-level application configuration object."""
    db: DbConfig
    crawl: CrawlConfig
    analysis: AnalysisConfig
    regime: RegimeConfig
    archive: ArchiveConfig
    llm: LlmConfig
    log_level: str = "INFO"
    timezone: str = "Asia/Seoul"
