
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.domain.models import NewsArticleMeta


class MainNewsParser:
    """Parses Naver Finance mainnews HTML into NewsArticleMeta objects."""

    def parse(self, html: str, crawled_at: datetime) -> List[NewsArticleMeta]:
        """Return list of NewsArticleMeta from a mainnews page HTML."""
        from bs4 import BeautifulSoup
        import hashlib
        
        soup = BeautifulSoup(html, 'lxml')
        articles = []
        
        # Target the specific list structure of Naver Finance Main News
        # Structure: ul.newsList > li > dl > dd.articleSubject > a
        article_items = soup.select('ul.newsList li dl')
        
        for item in article_items:
            try:
                subject_elem = item.select_one('dd.articleSubject a')
                if not subject_elem:
                    continue
                    
                title = subject_elem.get_text(strip=True)
                url = subject_elem.get('href', '')
                
                if not title or not url:
                    continue
                
                # Make URL absolute if relative
                if url.startswith('/'):
                    url = f"https://finance.naver.com{url}"
                elif not url.startswith('http'):
                    url = f"https://finance.naver.com/{url}"
                
                # Generate ID from URL
                article_id = hashlib.md5(url.encode()).hexdigest()[:16]
                
                # Extract publisher and summary
                publisher = None
                summary = None
                
                summary_elem = item.select_one('dd.articleSummary')
                if summary_elem:
                    # Publisher is usually in a span with class 'press'
                    press_elem = summary_elem.select_one('span.press')
                    if press_elem:
                        publisher = press_elem.get_text(strip=True)
                    
                    # Summary is the text in dd.articleSummary, often truncated
                    # We can just get all text, or try to exclude the press/date spans
                    # For simplicity, let's get all text and maybe clean up later if needed
                    summary = summary_elem.get_text(strip=True)
                
                articles.append(NewsArticleMeta(
                    id=article_id,
                    title=title,
                    url=url,
                    publisher=publisher,
                    category="MainNews", # Default category for main news
                    summary=summary,
                    published_at=crawled_at,  # Use crawled_at as fallback
                    crawled_at=crawled_at,
                ))
            except Exception:
                # Skip malformed items
                continue
        
        return articles
