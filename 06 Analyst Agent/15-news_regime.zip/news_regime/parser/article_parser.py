
from __future__ import annotations

from news_regime.domain.models import NewsArticleMeta, NewsArticleDetail


class ArticleParser:
    """Parses Naver article HTML into NewsArticleDetail."""

    def parse(self, html: str, meta: NewsArticleMeta) -> NewsArticleDetail:
        """Return NewsArticleDetail from article HTML and metadata."""
        from bs4 import BeautifulSoup
        
        soup = BeautifulSoup(html, 'lxml')
        
        # Extract body text - try common selectors
        body_elem = (
            soup.select_one('div.article_body, div.articleBody, div#articleBodyContents, div.news_article') or
            soup.select_one('div[itemprop="articleBody"]') or
            soup.select_one('article, div.content')
        )
        
        body_text = ""
        if body_elem:
            # Remove script and style tags
            for tag in body_elem.find_all(['script', 'style']):
                tag.decompose()
            body_text = body_elem.get_text(separator='\n', strip=True)
        
        # Extract reporter
        reporter = None
        reporter_elem = soup.select_one('.reporter, .byline, .author, span[itemprop="author"]')
        if reporter_elem:
            reporter = reporter_elem.get_text(strip=True)
        
        # Extract tags/keywords
        tags = []
        tag_elems = soup.select('.tag, .keyword, a[rel="tag"]')
        for tag_elem in tag_elems:
            tag_text = tag_elem.get_text(strip=True)
            if tag_text:
                tags.append(tag_text)
        
        return NewsArticleDetail(
            meta=meta,
            body_text=body_text,
            reporter=reporter,
            tags=tags if tags else None,
        )
