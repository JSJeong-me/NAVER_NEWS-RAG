"""Tests for crawler and HTTP client functionality."""

import pytest
from datetime import datetime
from zoneinfo import ZoneInfo
from news_regime.crawler.http_client import HttpClient, HttpResponse
from news_regime.config.models import CrawlConfig


class TestHttpClient:
    """Test HTTP client functionality."""
    
    def test_http_client_initialization(self):
        """Test HttpClient can be created."""
        client = HttpClient(
            base_url="https://example.com",
            timeout=10.0,
            user_agent="test_agent"
        )
        assert client.base_url == "https://example.com"
        assert client.timeout == 10.0
        assert client.user_agent == "test_agent"
    
    def test_http_response_creation(self):
        """Test HttpResponse dataclass."""
        response = HttpResponse(
            url="https://example.com/test",
            status_code=200,
            headers={"content-type": "text/html"},
            text="<html>test</html>",
            elapsed_sec=0.5
        )
        assert response.status_code == 200
        assert "test" in response.text
