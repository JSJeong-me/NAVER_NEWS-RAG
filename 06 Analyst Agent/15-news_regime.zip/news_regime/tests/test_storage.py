"""Tests for storage repositories."""

import pytest
from datetime import datetime
from zoneinfo import ZoneInfo
from news_regime.storage.db import DbSessionManager
from news_regime.storage.repositories.news_repo import NewsRepository
from news_regime.storage.repositories.mapping_repo import SymbolMapRepository
from news_regime.config.models import DbConfig
from news_regime.domain.models import NewsArticleMeta, SymbolMatch


class TestNewsRepository:
    """Test news repository."""
    
    def test_insert_and_retrieve(self):
        """Test storing and retrieving news."""
        config = DbConfig(dsn="memory://")
        manager = DbSessionManager(config)
        session = manager.create_session()
        repo = NewsRepository()
        
        now = datetime.now(ZoneInfo("Asia/Seoul"))
        meta = NewsArticleMeta(
            id="test123",
            title="Test Article",
            url="http://test.com/article",
            publisher="Test",
            category="Economy",
            summary=None,
            published_at=now,
            crawled_at=now
        )
        
        # Insert
        news_id = repo.insert_news_meta(session, meta)
        assert news_id is not None
        
        # Check exists
        exists = repo.exists_by_url(session, "http://test.com/article")
        assert exists is True


class TestSymbolMapRepository:
    """Test symbol mapping repository."""
    
    def test_insert_and_retrieve_mappings(self):
        """Test storing and retrieving symbol mappings."""
        config = DbConfig(dsn="memory://")
        manager = DbSessionManager(config)
        session = manager.create_session()
        repo = SymbolMapRepository()
        
        matches = [
            SymbolMatch(news_id="news1", symbol="005930", match_score=0.8),
            SymbolMatch(news_id="news1", symbol="000660", match_score=0.5),
        ]
        
        repo.insert_mappings(session, matches)
        
        # Retrieve
        retrieved = repo.get_mappings_for_news_ids(session, ["news1"])
        assert len(retrieved) == 2
