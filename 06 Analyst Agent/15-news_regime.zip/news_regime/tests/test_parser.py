"""Tests for parser functionality."""

import pytest
from datetime import datetime
from zoneinfo import ZoneInfo
from news_regime.parser.mainnews_parser import MainNewsParser
from news_regime.parser.article_parser import ArticleParser
from news_regime.domain.models import NewsArticleMeta


class TestMainNewsParser:
    """"Test mainnews HTML parsing."""
    
    def test_parse_simple_html(self):
        """Test parsing simple HTML with article links."""
        html = """
        <div class="newsList">
            <a href="/news/article1.html">삼성전자 주가 상승</a>
        </div>
        """
        parser = MainNewsParser()
        now = datetime.now(ZoneInfo("Asia/Seoul"))
        articles = parser.parse(html, now)
        
        # Should find articles (or zero if selector doesn't match)
        assert isinstance(articles, list)


class TestArticleParser:
    """Test article detail parsing."""
    
    def test_parse_article_html(self):
        """Test parsing article HTML."""
        html = """
        <div class="article_body">
            <p>This is the article body text.</p>
        </div>
        <span class="reporter">John Doe</span>
        """
        meta = NewsArticleMeta(
            id="test123",
            title="Test Article",
            url="http://test.com/article",
            publisher="Test Publisher",
            category="Economy",
            summary=None,
            published_at=datetime.now(ZoneInfo("Asia/Seoul")),
            crawled_at=datetime.now(ZoneInfo("Asia/Seoul"))
        )
        
        parser = ArticleParser()
        detail = parser.parse(html, meta)
        
        assert detail.meta == meta
        assert "article body" in detail.body_text.lower()
        assert detail.reporter == "John Doe" or detail.reporter is None
