"""Tests for analysis functionality."""

import pytest
from datetime import datetime
from zoneinfo import ZoneInfo
from news_regime.analysis.sentiment import RuleBasedSentimentAnalyzer
from news_regime.analysis.risk import RuleBasedRiskTagger
from news_regime.analysis.impact import ImpactScorer
from news_regime.domain.models import NewsArticleMeta, NewsArticleDetail


def create_test_article(title: str, body: str):
    """Helper to create test article."""
    now = datetime.now(ZoneInfo("Asia/Seoul"))
    meta = NewsArticleMeta(
        id="test123",
        title=title,
        url="http://test.com",
        publisher="Test",
        category="Economy",
        summary=None,
        published_at=now,
        crawled_at=now
    )
    return NewsArticleDetail(meta=meta, body_text=body)


class TestSentimentAnalyzer:
    """Test sentiment analysis."""
    
    def test_positive_sentiment(self):
        """Test positive news detection."""
        analyzer = RuleBasedSentimentAnalyzer()
        article = create_test_article(
            "주가 상승",
            "삼성전자 주가가 급등하면서 수익이 증가했습니다."
        )
        score = analyzer.analyze(article)
        assert score > 0  # Should be positive
    
    def test_negative_sentiment(self):
        """Test negative news detection."""
        analyzer = RuleBasedSentimentAnalyzer()
        article = create_test_article(
            "주가 하락",
            "실적 부진으로 주가가 급락하고 손실이 발생했습니다."
        )
        score = analyzer.analyze(article)
        assert score < 0  # Should be negative
    
    def test_neutral_sentiment(self):
        """Test neutral news."""
        analyzer = RuleBasedSentimentAnalyzer()
        article = create_test_article(
            "일반 뉴스",
            "회사가 새로운 제품을 출시했습니다."
        )
        score = analyzer.analyze(article)
        assert -1.0 <= score <= 1.0


class TestRiskTagger:
    """Test risk tagging."""
    
    def test_regulatory_risk(self):
        """Test regulatory risk detection."""
        tagger = RuleBasedRiskTagger()
        article = create_test_article(
            "규제 조사",
            "금융위원회가 조사를 시작했습니다."
        )
        flags = tagger.tag(article)
        assert flags.regulatory_risk is True
    
    def test_no_risk(self):
        """Test clean article."""
        tagger = RuleBasedRiskTagger()
        article = create_test_article(
            "일반 뉴스",
            "회사가 신제품을 발표했습니다."
        )
        flags = tagger.tag(article)
        # May or may not have flags depending on keywords


class TestImpactScorer:
    """Test impact scoring."""
    
    def test_high_impact(self):
        """Test high impact article."""
        scorer = ImpactScorer()
        long_body = "테스트 " * 500  # Long article
        article = create_test_article(
            "중요한 뉴스입니다 이것은 매우 중요합니다",
            long_body
        )
        article.reporter = "John Doe"
        article.tags = ["tag1", "tag2"]
        
        score = scorer.score(article)
        assert score > 0.5  # Should be high impact
