"""Tests for symbol mapping functionality."""

import pytest
from datetime import datetime
from zoneinfo import ZoneInfo
from news_regime.mapping.symbol_dictionary import SymbolDictionary
from news_regime.mapping.matcher import SymbolMatcher
from news_regime.domain.models import NewsArticleMeta, NewsArticleDetail


class TestSymbolDictionary:
    """Test symbol dictionary."""
    
    def test_load_symbols(self):
        """Test loading symbol dictionary."""
        dict = SymbolDictionary()
        dict.load()
        symbols = dict.get_all()
        
        assert len(symbols) > 0
        assert symbols[0].symbol is not None
        assert symbols[0].name_kr is not None
    
    def test_find_by_symbol(self):
        """Test finding symbol by code."""
        dict = SymbolDictionary()
        dict.load()
        
        # Samsung Electronics
        samsung = dict.find_by_symbol("005930")
        assert samsung is not None
        assert samsung.name_kr == "삼성전자"


class TestSymbolMatcher:
    """Test symbol matching."""
    
    def test_match_symbols(self):
        """Test matching articles to symbols."""
        dict = SymbolDictionary()
        dict.load()
        
        matcher = SymbolMatcher(dict)
        
        now = datetime.now(ZoneInfo("Asia/Seoul"))
        meta = NewsArticleMeta(
            id="test123",
            title="삼성전자 주가 상승",
            url="http://test.com",
            publisher="Test",
            category="Economy",
            summary=None,
            published_at=now,
            crawled_at=now
        )
        
        detail = NewsArticleDetail(
            meta=meta,
            body_text="삼성전자가 오늘 급등했습니다.",
            reporter=None,
            tags=None
        )
        
        matches = matcher.match_symbols(detail)
        
        # Should find Samsung
        assert len(matches) > 0
        assert any(m.symbol == "005930" for m in matches)
