"""Test suite for news_regime package."""
