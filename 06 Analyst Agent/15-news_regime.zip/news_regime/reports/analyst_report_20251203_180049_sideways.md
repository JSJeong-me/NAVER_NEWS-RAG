# Market Analyst Report (STUB)
**Regime**: sideways
**Volatility**: WATCH

## Executive Summary
The market is currently in a sideways state with WATCH volatility.
**ALERT**: Regime changed from risk_on to sideways.
Reason: Recent regime change: risk_on_to_sideways

## Top Recommendations
- **035420** (ACTIVE): Score 0.68
- **005930** (ACTIVE): Score 0.49

## Focus Symbols
- **005930**: 5 articles, Sentiment 0.58
- **207940**: 1 articles, Sentiment 1.00
- **035420**: 1 articles, Sentiment 0.30

## Key News Drivers
- 의무 보유 강화에…'단타 투기장' 된 스팩[마켓시그널]
  *Impact*: sector (mixed)
- "韓증시 여전히 저평가"… 6천피 부른 맥쿼리
  *Impact*: sector (mixed)
- 배당 기대감에 달리는 은행株, 계속 갈까
  *Impact*: market (mixed)
- '뜨거운 감자' AI 거품론, 또하나의 기회일 수도
  *Impact*: sector (mixed)
- 원화 추가 약세는 제한적[투자의 창]
  *Impact*: market (mixed)