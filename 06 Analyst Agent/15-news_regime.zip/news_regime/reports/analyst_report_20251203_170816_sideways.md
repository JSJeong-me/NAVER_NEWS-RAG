# Market Analyst Report
**Regime**: sideways
**Volatility**: CAUTION

## Executive Summary
The market is currently in a sideways state with CAUTION volatility.
**ALERT**: Regime changed from risk_on to sideways.
Reason: Elevated news impact (0.15); Elevated risk flag ratio (10.00%); Recent regime change: RegimeLabel.RISK_ON_to_RegimeLabel.SIDEWAYS

## Top Recommendations
- **035420** (ACTIVE): Score 0.68
- **005930** (ACTIVE): Score 0.49

## Focus Symbols
- **005930**: 5 articles, Sentiment 0.58
- **207940**: 1 articles, Sentiment 1.00
- **035420**: 1 articles, Sentiment 0.30

## Key News Drivers
- “드디어 올 게 왔다” 주식 사고팔면 세금 더 내야…조심해야 할 곳은? [투자360]
  *Impact*: market (mixed)
- 구글, 엔비디아 누가 이기든 메모리 특수…증권가 "삼전·SK 40% 상승 여력"
  *Impact*: sector (mixed)
- ‘거래세 인상’…2차전지·레버리지·바이오 직격탄
  *Impact*: market (mixed)
- 'AI 특수' 삼성전기, 목표주가 33만원으로.. "KT, 바닥 탄탄해졌지만 보수적 접근" [株토피아]
  *Impact*: sector (mixed)
- “부동산에 잠긴 돈, AI·코인으로 돌려라”…민주당 TF, ‘유동성 G2’ 전략 제안
  *Impact*: sector (negative)