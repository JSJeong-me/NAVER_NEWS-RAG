#!/usr/bin/env bash

# 1) 에러 나면 바로 종료하도록 설정 (옵션)
set -e

# 2) conda 초기화 스크립트 로드
#    miniconda3 설치 경로에 맞게 수정 (지금 정보 기준으로 아래가 맞음)
source ~/miniconda3/etc/profile.d/conda.sh

# 3) base 환경 활성화
conda activate base

# 4) OpenAI API 키 설정
#    실제 키로 바꾸세요. (또는 별도 파일에서 source 해도 됨)
export OPENAI_API_KEY="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"

# 5) 프로젝트 디렉터리로 이동
cd /home/ubuntu/news_regime

# 6) (옵션) 크롤러 먼저 실행 – config에서 이미 돌리고 있다면 생략 가능
# ./run_crawler.sh

# 7) Analyst Agent 1회 실행
python -m analyst_agent.run_once
