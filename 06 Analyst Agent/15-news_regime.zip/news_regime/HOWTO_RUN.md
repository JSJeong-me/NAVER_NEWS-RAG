# How to Run the News Crawler

## Problem: Import Errors

If you see `ModuleNotFoundError: No module named 'news_regime'`, this is because the package structure uses internal imports with the `news_regime.` prefix, which requires proper package installation.

## ✅ Solution: Use the Wrapper Script

```bash
cd /home/ubuntu/news_regime
./run_crawler.sh
```

This script:
1. Checks if the package is installed
2. Installs it automatically if needed
3. Runs the crawler
4. Shows results (crawled news, recommendations, market regime)

## Alternative: Manual Package Installation + Python Execution

```bash
# One-time setup
cd /home/ubuntu/news_regime
pip install -e .

# Then you can run Python commands directly
python -c "from cli.hourly_job import HourlyJob; HourlyJob().run_once()"
```

## Why This Is Needed

The package structure is:
```
/home/ubuntu/news_regime/
├── cli/hourly_job.py       # Uses: from news_regime.common import ...
├── crawler/naver_client.py # Uses: from news_regime.parser import ...
├── analysis/sentiment.py   # Uses: from news_regime.domain import ...
└── ... (all files use news_regime. imports)
```

All internal files use `news_regime.` imports, so the package must be properly installed for Python to find these modules.

## Quick Commands

```bash
# Run the crawler
./run_crawler.sh

# Query the database (various options)
./query_db.sh news           # Show recent news articles
./query_db.sh analysis       # Show sentiment/risk analysis statistics
./query_db.sh symbols        # Show symbol mappings
./query_db.sh recommendations # Show trading recommendations
./query_db.sh regime         # Show market regime history
./query_db.sh all            # Show everything

# Query options
./query_db.sh news --hours 48 --limit 10  # Last 48 hours, limit 10 results
./list_news.sh               # Simple news listing

# Or after installation:
python -c "from cli.hourly_job import HourlyJob; HourlyJob().run_once()"

# Run tests (always works)
python -m pytest tests/ -v
```

## Database Query Tools

The project includes powerful CLI tools to query the SQLite database:

### `query_db.sh` - Comprehensive Database Query Tool

Query different aspects of the news database:

```bash
# Show recent news articles
./query_db.sh news --hours 24 --limit 50

# Show sentiment and risk analysis statistics
./query_db.sh analysis --hours 24

# Show symbol-to-news mappings
./query_db.sh symbols

# Show trading recommendations
./query_db.sh recommendations --limit 20

# Show market regime classification history
./query_db.sh regime --limit 10

# Show everything at once
./query_db.sh all --hours 24 --limit 10
```

### `list_news.sh` - Simple News Listing

Quick way to see the latest news:

```bash
./list_news.sh
```
