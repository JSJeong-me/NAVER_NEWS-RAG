"""Setup file for news_regime package."""

from setuptools import setup, find_packages

setup(
    name="news_regime",
    version="0.1.0",
    description="Naver Finance news crawler with LLM-based analysis/recommendation",
    # The package modules are directly in the current directory
    packages=find_packages(where="."),
    package_dir={"": "."},
    python_requires=">=3.10",
    install_requires=[
        "openai>=1.0.0",
        "httpx>=0.24.0",
        "beautifulsoup4>=4.12.0",
        "lxml>=4.9.0",
    ],
    extras_require={
        "test": [
            "pytest>=7.4.0",
            "pytest-mock>=3.11.0",
            "pytest-cov>=4.1.0",
        ],
    },
)

