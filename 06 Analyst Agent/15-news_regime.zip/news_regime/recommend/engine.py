
from __future__ import annotations
from datetime import datetime
from typing import List, Optional

from news_regime.domain.models import SymbolAggregatedStats, RecommendationItem
from .policy import RecommendationPolicy


class RecommendationEngine:
    """Builds RecommendationItem list from aggregated stats."""

    def __init__(self, policy: RecommendationPolicy, summarizer: Optional[object] = None) -> None:
        self.policy = policy
        self.summarizer = summarizer  # LLM-based summarizer (optional)

    def generate_recommendations(
        self,
        aggregated_stats: List[SymbolAggregatedStats],
        as_of: datetime,
        top_n: int | None = None,
    ) -> List[RecommendationItem]:
        """Generate ranked list of buy recommendations."""
        recommendations = []
        
        for stats in aggregated_stats:
            # Filter by policy
            if not self.policy.is_buy_candidate(stats):
                continue
            
            # Compute composite score
            composite = self.policy.compute_composite_score(stats)
            
            # Build risk summary
            risk_summary = {
                "regulatory_risk_ratio": stats.regulatory_risk_ratio,
                "earnings_risk_ratio": stats.earnings_risk_ratio,
                "credit_risk_ratio": stats.credit_risk_ratio,
            }
            
            # Generate reason (simplified - real version would use LLM summarizer)
            reason = f"긍정적 뉴스 {stats.num_articles}건, 평균 심리지수 {stats.avg_sentiment:.2f}"
            
            recommendations.append(RecommendationItem(
                symbol=stats.symbol,
                created_at=as_of,
                sentiment_score=stats.avg_sentiment,
                impact_score=stats.avg_impact,
                composite_score=composite,
                risk_summary=risk_summary,
                status="ACTIVE",
                reason_summary=reason,
            ))
        
        # Sort by composite score descending
        recommendations.sort(key=lambda r: r.composite_score, reverse=True)
        
        # Return top N if specified
        if top_n is not None:
            return recommendations[:top_n]
        
        return recommendations
