
from __future__ import annotations
from news_regime.config.models import AnalysisConfig
from news_regime.domain.models import SymbolAggregatedStats


class RecommendationPolicy:
    """Rule-based filter & scoring for buy candidates."""

    def __init__(self, config: AnalysisConfig) -> None:
        self.config = config

    def is_buy_candidate(self, stats: SymbolAggregatedStats) -> bool:
        """Filter based on sentiment thresholds and risk ratios."""
        # Positive sentiment required
        if stats.avg_sentiment < self.config.sentiment_positive_threshold:
            return False
        
        # Minimum impact threshold
        if stats.avg_impact < self.config.min_impact_for_buy:
            return False
        
        # Regulatory risk filter
        if stats.regulatory_risk_ratio > self.config.max_regulatory_risk_ratio_for_buy:
            return False
        
        # Minimum article count
        if stats.num_articles < self.config.min_articles_for_symbol:
            return False
        
        return True

    def compute_composite_score(self, stats: SymbolAggregatedStats) -> float:
        """Compute composite score as weighted combination."""
        # Weighted combination: 60% sentiment, 40% impact
        sentiment_component = (stats.avg_sentiment + 1.0) / 2.0  # Normalize to 0-1
        impact_component = stats.avg_impact
        
        composite = 0.6 * sentiment_component + 0.4 * impact_component
        return min(max(composite, 0.0), 1.0)
