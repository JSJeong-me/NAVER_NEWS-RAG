
from __future__ import annotations
from typing import List

from news_regime.domain.models import NewsArticleDetail, SymbolMatch
from .symbol_dictionary import SymbolDictionary


class SymbolMatcher:
    """Heuristic matcher from article text to one or more symbols."""

    def __init__(self, symbol_dict: SymbolDictionary) -> None:
        self.symbol_dict = symbol_dict

    def match_symbols(self, article: NewsArticleDetail) -> List[SymbolMatch]:
        """Return list of SymbolMatch for given article."""
        matches = []
        text = f"{article.meta.title} {article.body_text}".lower()
        
        for sym_info in self.symbol_dict.get_all():
            # Check if any alias appears in title or body
            score = 0.0
            
            # Higher score for title matches
            if sym_info.name_kr.lower() in article.meta.title.lower():
                score += 0.8
            
            # Check aliases in body
            if sym_info.aliases:
                for alias in sym_info.aliases:
                    if alias.lower() in text:
                        score += 0.3
                        break
            
            # Only add if we found a match
            if score > 0:
                matches.append(SymbolMatch(
                    news_id=article.meta.id,
                    symbol=sym_info.symbol,
                    match_score=min(score, 1.0),
                ))
        
        return matches
