
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class SymbolInfo:
    symbol: str
    name_kr: str
    name_en: Optional[str] = None
    aliases: List[str] | None = None


class SymbolDictionary:
    """In-memory dictionary of all tradable symbols."""

    def __init__(self) -> None:
        self._symbols: List[SymbolInfo] = []

    def load(self) -> None:
        """Load symbol list from external source (DB/file/API)."""
        # Hardcoded list of major Korean stocks for testing
        self._symbols = [
            SymbolInfo(symbol="005930", name_kr="삼성전자", name_en="Samsung Electronics", aliases=["삼성전자", "삼성", "Samsung"]),
            SymbolInfo(symbol="000660", name_kr="SK하이닉스", name_en="SK Hynix", aliases=["SK하이닉스", "하이닉스", "SK Hynix"]),
            SymbolInfo(symbol="005380", name_kr="현대차", name_en="Hyundai Motor", aliases=["현대차", "현대자동차", "Hyundai"]),
            SymbolInfo(symbol="051910", name_kr="LG화학", name_en="LG Chem", aliases=["LG화학", "엘지화학"]),
            SymbolInfo(symbol="006400", name_kr="삼성SDI", name_en="Samsung SDI", aliases=["삼성SDI", "SDI"]),
            SymbolInfo(symbol="035720", name_kr="카카오", name_en="Kakao", aliases=["카카오", "Kakao"]),
            SymbolInfo(symbol="035420", name_kr="NAVER", name_en="NAVER", aliases=["네이버", "NAVER", "Naver"]),
            SymbolInfo(symbol="068270", name_kr="셀트리온", name_en="Celltrion", aliases=["셀트리온"]),
            SymbolInfo(symbol="207940", name_kr="삼성바이오로직스", name_en="Samsung Biologics", aliases=["삼성바이오", "삼성바이오로직스"]),
            SymbolInfo(symbol="005490", name_kr="POSCO홀딩스", name_en="POSCO Holdings", aliases=["POSCO", "포스코"]),
        ]

    def get_all(self) -> List[SymbolInfo]:
        """Return all loaded symbols."""
        return self._symbols

    def find_by_symbol(self, symbol: str) -> Optional[SymbolInfo]:
        """Return SymbolInfo matching symbol (if any)."""
        for sym_info in self._symbols:
            if sym_info.symbol == symbol:
                return sym_info
        return None
