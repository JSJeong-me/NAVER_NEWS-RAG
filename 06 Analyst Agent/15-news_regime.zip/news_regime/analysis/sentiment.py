
from __future__ import annotations
from news_regime.domain.models import NewsArticleDetail


class SentimentAnalyzer:
    """Base interface for sentiment analyzers."""

    def analyze(self, article: NewsArticleDetail) -> float:
        raise NotImplementedError


class RuleBasedSentimentAnalyzer(SentimentAnalyzer):
    """Simple keyword/dictionary-based sentiment scoring stub."""

    def analyze(self, article: NewsArticleDetail) -> float:
        """Calculate sentiment score from -1 (negative) to +1 (positive)."""
        # Korean sentiment keywords
        positive_words = [
            '상승', '증가', '호재', '성장', '급등', '개선', '확대', '긍정',
            '성공', '수익', '이익', '상향', '강세', '돌파', '최고', '신고가',
        ]
        negative_words = [
            '하락', '감소', '악재', '하락', '급락', '악화', '축소', '부정',
            '실패', '손실', '적자', '하향', '약세', '붕괴', '최저', '신저가',
        ]
        
        text = f"{article.meta.title} {article.body_text}".lower()
        
        pos_count = sum(1 for word in positive_words if word in text)
        neg_count = sum(1 for word in negative_words if word in text)
        
        total = pos_count + neg_count
        if total == 0:
            return 0.0
        
        sentiment = (pos_count - neg_count) / total
        return max(-1.0, min(1.0, sentiment))
