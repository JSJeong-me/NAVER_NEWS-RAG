
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.domain.models import (
    ArticleSentiment,
    SymbolAggregatedStats,
    GlobalNewsStats,
    SymbolMatch,
)


class AggregationService:
    """Aggregate article-level results into symbol & global stats."""

    def aggregate_by_symbol(
        self,
        sentiments: List[ArticleSentiment],
        symbol_map: List[SymbolMatch],
        window_start: datetime,
        window_end: datetime,
    ) -> List[SymbolAggregatedStats]:
        """Aggregate article sentiments by symbol."""
        from collections import defaultdict
        
        # Group sentiments by symbol
        symbol_groups = defaultdict(list)
        for match in symbol_map:
            for sentiment in sentiments:
                if sentiment.news_id == match.news_id:
                    symbol_groups[match.symbol].append(sentiment)
        
        # Aggregate for each symbol
        results = []
        for symbol, sent_list in symbol_groups.items():
            if not sent_list:
                continue
            
            num_articles = len(sent_list)
            avg_sentiment = sum(s.sentiment_score for s in sent_list) / num_articles
            max_sentiment = max(s.sentiment_score for s in sent_list)
            avg_impact = sum(s.impact_score for s in sent_list) / num_articles
            max_impact = max(s.impact_score for s in sent_list)
            
            regulatory_ratio = sum(1 for s in sent_list if s.regulatory_risk_flag) / num_articles
            earnings_ratio = sum(1 for s in sent_list if s.earnings_risk_flag) / num_articles
            credit_ratio = sum(1 for s in sent_list if s.credit_risk_flag) / num_articles
            
            results.append(SymbolAggregatedStats(
                symbol=symbol,
                window_start=window_start,
                window_end=window_end,
                num_articles=num_articles,
                avg_sentiment=avg_sentiment,
                max_sentiment=max_sentiment,
                avg_impact=avg_impact,
                max_impact=max_impact,
                regulatory_risk_ratio=regulatory_ratio,
                earnings_risk_ratio=earnings_ratio,
                credit_risk_ratio=credit_ratio,
                last_article_time=window_end,
            ))
        
        return results

    def aggregate_global(
        self,
        sentiments: List[ArticleSentiment],
        window_start: datetime,
        window_end: datetime,
    ) -> GlobalNewsStats:
        """Aggregate all sentiments into global statistics."""
        if not sentiments:
            return GlobalNewsStats(
                window_start=window_start,
                window_end=window_end,
                num_articles=0,
                avg_sentiment=0.0,
                positive_ratio=0.0,
                negative_ratio=0.0,
                regulatory_risk_ratio=0.0,
                earnings_risk_ratio=0.0,
                credit_risk_ratio=0.0,
                macro_news_ratio=0.0,
                sector_news_ratio=0.0,
                single_stock_news_ratio=0.0,
            )
        
        num_articles = len(sentiments)
        avg_sentiment = sum(s.sentiment_score for s in sentiments) / num_articles
        positive_ratio = sum(1 for s in sentiments if s.sentiment_score > 0.2) / num_articles
        negative_ratio = sum(1 for s in sentiments if s.sentiment_score < -0.2) / num_articles
        
        regulatory_ratio = sum(1 for s in sentiments if s.regulatory_risk_flag) / num_articles
        earnings_ratio = sum(1 for s in sentiments if s.earnings_risk_flag) / num_articles
        credit_ratio = sum(1 for s in sentiments if s.credit_risk_flag) / num_articles
        
        return GlobalNewsStats(
            window_start=window_start,
            window_end=window_end,
            num_articles=num_articles,
            avg_sentiment=avg_sentiment,
            positive_ratio=positive_ratio,
            negative_ratio=negative_ratio,
            regulatory_risk_ratio=regulatory_ratio,
            earnings_risk_ratio=earnings_ratio,
            credit_risk_ratio=credit_ratio,
            macro_news_ratio=0.3,  # Placeholder
            sector_news_ratio=0.4,  # Placeholder
            single_stock_news_ratio=0.3,  # Placeholder
        )
