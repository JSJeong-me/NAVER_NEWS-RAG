"""News analysis layer: sentiment, risk, impact, aggregation."""
