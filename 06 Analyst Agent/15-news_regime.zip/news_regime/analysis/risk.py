
from __future__ import annotations
from dataclasses import dataclass
from news_regime.domain.models import NewsArticleDetail


@dataclass
class RiskFlags:
    regulatory_risk: bool
    earnings_risk: bool
    credit_risk: bool


class RiskTagger:
    """Base interface for risk tagging."""

    def tag(self, article: NewsArticleDetail) -> RiskFlags:
        raise NotImplementedError


class RuleBasedRiskTagger(RiskTagger):
    """Keyword-based risk tagging stub."""

    def tag(self, article: NewsArticleDetail) -> RiskFlags:
        """Tag article with risk flags based on keywords."""
        text = f"{article.meta.title} {article.body_text}".lower()
        
        # Regulatory risk keywords
        regulatory_keywords = ['규제', '조사', '처벌', '제재', '소송', '법원', '검찰', '금융위']
        regulatory_risk = any(keyword in text for keyword in regulatory_keywords)
        
        # Earnings risk keywords
        earnings_keywords = ['실적', '적자', '손실', '하락', '감소', '부진', '저조']
        earnings_risk = any(keyword in text for keyword in earnings_keywords)
        
        # Credit risk keywords
        credit_keywords = ['부채', '차입', '신용', '등급', '하향', '유동성', '파산']
        credit_risk = any(keyword in text for keyword in credit_keywords)
        
        return RiskFlags(
            regulatory_risk=regulatory_risk,
            earnings_risk=earnings_risk,
            credit_risk=credit_risk,
        )
