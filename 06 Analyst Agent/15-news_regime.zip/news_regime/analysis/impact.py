
from __future__ import annotations
from news_regime.domain.models import NewsArticleDetail


class ImpactScorer:
    """Assign a rough impact score to each article (0~1)."""

    def score(self, article: NewsArticleDetail) -> float:
        """Assign impact score from 0 to 1 based on article characteristics."""
        score = 0.0
        
        # Longer articles = higher impact
        body_length = len(article.body_text)
        if body_length > 2000:
            score += 0.4
        elif body_length > 1000:
            score += 0.2
        
        # Title length and prominence
        if len(article.meta.title) > 30:
            score += 0.2
        
        # Has reporter = more credible
        if article.reporter:
            score += 0.2
        
        # Has tags = more structured
        if article.tags:
            score += 0.2
        
        return min(score, 1.0)
