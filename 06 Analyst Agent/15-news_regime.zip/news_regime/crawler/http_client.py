
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional


@dataclass
class HttpResponse:
    url: str
    status_code: int
    headers: Dict[str, str]
    text: str
    elapsed_sec: float


class HttpClient:
    """Thin HTTP client abstraction.

    Real implementation should use httpx/requests with retry & rate limiting.
    """

    def __init__(self, base_url: str, timeout: float, user_agent: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.user_agent = user_agent

    def get(self, path: str, params: Optional[Dict[str, str]] = None) -> HttpResponse:
        """Perform GET to base_url + path and return HttpResponse.

        Implements retry logic and rate limiting.
        """
        import time
        import httpx
        
        url = f"{self.base_url}{path}"
        headers = {"User-Agent": self.user_agent}
        
        for attempt in range(3):  # max 3 attempts
            try:
                start_time = time.time()
                with httpx.Client(timeout=self.timeout) as client:
                    response = client.get(url, params=params, headers=headers)
                    response.raise_for_status()
                    elapsed = time.time() - start_time
                    
                    return HttpResponse(
                        url=str(response.url),
                        status_code=response.status_code,
                        headers=dict(response.headers),
                        text=response.text,
                        elapsed_sec=elapsed,
                    )
            except (httpx.HTTPError, httpx.TimeoutException) as e:
                if attempt == 2:  # last attempt
                    raise
                time.sleep(1.0 * (attempt + 1))  # backoff
        
        raise RuntimeError("Unreachable code")
