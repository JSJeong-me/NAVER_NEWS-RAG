
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.config.models import CrawlConfig
from news_regime.crawler.http_client import HttpClient
from news_regime.domain.models import NewsArticleMeta, NewsArticleDetail
from news_regime.parser.mainnews_parser import MainNewsParser
from news_regime.parser.article_parser import ArticleParser


class NaverNewsClient:
    """Fetches and parses Naver Finance mainnews and article pages."""

    def __init__(
        self,
        http_client: HttpClient,
        crawl_config: CrawlConfig,
        mainnews_parser: MainNewsParser,
        article_parser: ArticleParser,
    ) -> None:
        self.http_client = http_client
        self.crawl_config = crawl_config
        self.mainnews_parser = mainnews_parser
        self.article_parser = article_parser

    def fetch_mainnews_page(self) -> str:
        """Return HTML text of mainnews page."""
        url_path = self.crawl_config.mainnews_path
        response = self.http_client.get(url_path)
        return response.text

    def fetch_article_page(self, article_url: str) -> str:
        """Return HTML text of a single article page."""
        # Extract path from full URL if needed
        if article_url.startswith("http"):
            # Remove base URL to get path
            import urllib.parse
            parsed = urllib.parse.urlparse(article_url)
            path = parsed.path
            if parsed.query:
                path += f"?{parsed.query}"
        else:
            path = article_url
        
        response = self.http_client.get(path)
        return response.text

    def crawl_mainnews(self, crawled_at: datetime) -> List[NewsArticleMeta]:
        """Fetch + parse mainnews page into a list of NewsArticleMeta."""
        html = self.fetch_mainnews_page()
        articles = self.mainnews_parser.parse(html, crawled_at)
        return articles

    def crawl_article_detail(self, meta: NewsArticleMeta) -> NewsArticleDetail:
        """Fetch + parse a full article body for given metadata."""
        html = self.fetch_article_page(meta.url)
        detail = self.article_parser.parse(html, meta)
        return detail
