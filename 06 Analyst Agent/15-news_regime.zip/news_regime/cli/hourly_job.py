
from __future__ import annotations
from datetime import datetime, timedelta

from news_regime.common.logging import setup_logging
from news_regime.common.time_utils import now_in_timezone
from news_regime.config.loader import get_config
from news_regime.storage.db import DbSessionManager
from news_regime.crawler.http_client import HttpClient
from news_regime.crawler.naver_client import NaverNewsClient
from news_regime.parser.mainnews_parser import MainNewsParser
from news_regime.parser.article_parser import ArticleParser
from news_regime.preprocess.text_normalizer import TextNormalizer
from news_regime.preprocess.time_utils import TimeParser
from news_regime.mapping.symbol_dictionary import SymbolDictionary
from news_regime.mapping.matcher import SymbolMatcher
from news_regime.storage.repositories.news_repo import NewsRepository
from news_regime.storage.repositories.mapping_repo import SymbolMapRepository
from news_regime.storage.repositories.analysis_repo import AnalysisRepository
from news_regime.analysis.sentiment import RuleBasedSentimentAnalyzer
from news_regime.analysis.risk import RuleBasedRiskTagger
from news_regime.analysis.impact import ImpactScorer
from news_regime.analysis.aggregator import AggregationService
from news_regime.recommend.policy import RecommendationPolicy
from news_regime.recommend.engine import RecommendationEngine
from news_regime.regime.classifier import RegimeClassifier
from news_regime.storage.repositories.recommendation_repo import RecommendationRepository
from news_regime.storage.repositories.regime_repo import RegimeRepository
from news_regime.llm.client import LlmClient, LlmClientConfig
from news_regime.llm.summarizer import NewsSummarizer
from news_regime.llm.classifier import NewsClassifier
from news_regime.domain.models import ArticleSentiment


class HourlyJob:
    """Orchestrates 1-hour cycle: crawl -> analyze -> recommend -> regime."""

    def __init__(self) -> None:
        self.config = get_config()
        setup_logging(self.config.log_level)

        # DB
        self.session_manager = DbSessionManager(self.config.db)

        # LLM
        self.llm_client = LlmClient(
            LlmClientConfig(
                model_name=self.config.llm.model_name,
                temperature=self.config.llm.temperature,
                max_tokens=self.config.llm.max_tokens,
                request_timeout=self.config.llm.request_timeout,
            )
        )
        self.news_summarizer = NewsSummarizer(self.llm_client)
        self.news_classifier = NewsClassifier(self.llm_client)

        # HTTP / crawling
        self.http_client = HttpClient(
            base_url=self.config.crawl.base_url,
            timeout=self.config.crawl.request_timeout,
            user_agent=self.config.crawl.user_agent,
        )
        self.time_parser = TimeParser(self.config.timezone)
        self.mainnews_parser = MainNewsParser()
        self.article_parser = ArticleParser()
        self.text_normalizer = TextNormalizer()
        self.naver_client = NaverNewsClient(
            http_client=self.http_client,
            crawl_config=self.config.crawl,
            mainnews_parser=self.mainnews_parser,
            article_parser=self.article_parser,
        )

        # Mapping
        self.symbol_dict = SymbolDictionary()
        self.symbol_matcher = SymbolMatcher(self.symbol_dict)

        # Analysis
        self.sentiment_analyzer = RuleBasedSentimentAnalyzer()
        self.risk_tagger = RuleBasedRiskTagger()
        self.impact_scorer = ImpactScorer()
        self.aggregator = AggregationService()

        # Recommendation & Regime
        self.reco_policy = RecommendationPolicy(self.config.analysis)
        self.reco_engine = RecommendationEngine(self.reco_policy, summarizer=self.news_summarizer)
        self.regime_classifier = RegimeClassifier(self.config.regime, summarizer=self.news_summarizer)

        # Repositories
        self.news_repo = NewsRepository()
        self.mapping_repo = SymbolMapRepository()
        self.analysis_repo = AnalysisRepository()
        self.reco_repo = RecommendationRepository()
        self.regime_repo = RegimeRepository()

    def run_once(self, now: datetime | None = None) -> None:
        """Run one hourly cycle: crawl -> analyze -> recommend -> regime."""
        import logging
        logger = logging.getLogger(__name__)
        
        if now is None:
            now = now_in_timezone(self.config.timezone)
        
        logger.info(f"Starting hourly job at {now}")
        
        session = self.session_manager.create_session()
        
        # Step 1: Load symbol dictionary
        self.symbol_dict.load()
        logger.info(f"Loaded {len(self.symbol_dict.get_all())} symbols")
        
        # Step 2: Crawl mainnews page
        logger.info("Crawling mainnews...")
        news_articles = self.naver_client.crawl_mainnews(crawled_at=now)
        logger.info(f"Found {len(news_articles)} articles")
        
        # Step 3: Store metadata and crawl full article details
        crawled_details = []
        for meta in news_articles:
            # Skip if already exists
            if self.news_repo.exists_by_url(session, meta.url):
                continue
            
            # Save metadata
            news_id = self.news_repo.insert_news_meta(session, meta)
            
            # Crawl full article
            try:
                detail = self.naver_client.crawl_article_detail(meta)
                self.news_repo.insert_news_detail(session, detail, news_id)
                crawled_details.append(detail)
            except Exception as e:
                logger.warning(f"Failed to crawl {meta.url}: {e}")
                continue
        
        logger.info(f"Crawled {len(crawled_details)} new article details")
        
        # Step 4: Map to symbols
        all_matches = []
        for detail in crawled_details:
            matches = self.symbol_matcher.match_symbols(detail)
            all_matches.extend(matches)
        
        if all_matches:
            self.mapping_repo.insert_mappings(session, all_matches)
        logger.info(f"Created {len(all_matches)} symbol matches")
        
        # Step 5: Analyze sentiment/risk/impact
        sentiments = []
        for detail in crawled_details:
            sentiment_score = self.sentiment_analyzer.analyze(detail)
            risk_flags = self.risk_tagger.tag(detail)
            impact_score = self.impact_scorer.score(detail)
            
            sentiments.append(ArticleSentiment(
                news_id=detail.meta.id or "",
                sentiment_score=sentiment_score,
                regulatory_risk_flag=risk_flags.regulatory_risk,
                earnings_risk_flag=risk_flags.earnings_risk,
                credit_risk_flag=risk_flags.credit_risk,
                impact_score=impact_score,
            ))
        
        if sentiments:
            self.analysis_repo.insert_article_analysis(session, sentiments)
        logger.info(f"Analyzed {len(sentiments)} articles")
        
        # Step 6: Aggregate by symbol
        news_ids = [d.meta.id for d in crawled_details if d.meta.id]
        symbol_map = self.mapping_repo.get_mappings_for_news_ids(session, news_ids)
        
        window_start = now - timedelta(hours=self.config.analysis.aggregation_window_hours)
        window_end = now
        
        symbol_stats = self.aggregator.aggregate_by_symbol(
            sentiments, symbol_map, window_start, window_end
        )
        logger.info(f"Aggregated stats for {len(symbol_stats)} symbols")
        
        # Step 7: Generate recommendations
        recommendations = self.reco_engine.generate_recommendations(
            symbol_stats, as_of=now, top_n=10
        )
        
        if recommendations:
            self.reco_repo.insert_recommendations(session, recommendations)
        logger.info(f"Generated {len(recommendations)} recommendations")
        
        # Step 8: Classify regime
        global_stats = self.aggregator.aggregate_global(sentiments, window_start, window_end)
        regime = self.regime_classifier.classify(global_stats, as_of=now)
        self.regime_repo.insert_regime(session, regime)
        logger.info(f"Regime: {regime.regime_label} (confidence={regime.confidence:.2f})")
        
        logger.info("Hourly job complete")


def main() -> None:
    job = HourlyJob()
    now = now_in_timezone(job.config.timezone)
    job.run_once(now=now)


if __name__ == "__main__":
    main()
