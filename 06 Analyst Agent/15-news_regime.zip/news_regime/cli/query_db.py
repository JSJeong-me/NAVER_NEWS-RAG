#!/usr/bin/env python
"""CLI tool to query various aspects of the news database."""

from __future__ import annotations
import sys
import argparse
from datetime import datetime, timedelta

from news_regime.config.loader import get_config
from news_regime.storage.db import DbSessionManager
from news_regime.storage.repositories.news_repo import NewsRepository
from news_regime.storage.repositories.analysis_repo import AnalysisRepository
from news_regime.storage.repositories.mapping_repo import SymbolMapRepository
from news_regime.storage.repositories.recommendation_repo import RecommendationRepository
from news_regime.storage.repositories.regime_repo import RegimeRepository


def print_separator():
    """Print a separator line."""
    print(f"{'='*80}")


def query_news(session, hours=24, limit=50):
    """Query recent news articles."""
    news_repo = NewsRepository()
    end_time = datetime.now()
    start_time = end_time - timedelta(hours=hours)
    
    articles = news_repo.get_news_in_window(session, start_time, end_time)
    
    print_separator()
    print(f"News Articles (Last {hours} hours, {len(articles)} found)")
    print_separator()
    print()
    
    # Sort by crawled_at descending
    articles.sort(key=lambda a: a.crawled_at, reverse=True)
    
    for i, article in enumerate(articles[:limit], 1):
        print(f"{i}. {article.title}")
        print(f"   Publisher: {article.publisher or 'N/A'}")
        print(f"   Category: {article.category or 'N/A'}")
        print(f"   Crawled: {article.crawled_at}")
        print(f"   URL: {article.url}")
        if article.summary:
            summary = article.summary[:200] + "..." if len(article.summary) > 200 else article.summary
            print(f"   Summary: {summary}")
        print()


def query_analysis(session, hours=24):
    """Query article analysis (sentiment/risk)."""
    analysis_repo = AnalysisRepository()
    end_time = datetime.now()
    start_time = end_time - timedelta(hours=hours)
    
    analyses = analysis_repo.get_article_analysis_in_window(session, start_time, end_time)
    
    print_separator()
    print(f"Article Analysis (Last {hours} hours, {len(analyses)} found)")
    print_separator()
    print()
    
    if not analyses:
        print("No analysis data found.")
        return
    
    # Calculate statistics
    avg_sentiment = sum(a.sentiment_score for a in analyses) / len(analyses)
    avg_impact = sum(a.impact_score for a in analyses) / len(analyses)
    regulatory_risk_count = sum(1 for a in analyses if a.regulatory_risk_flag)
    earnings_risk_count = sum(1 for a in analyses if a.earnings_risk_flag)
    credit_risk_count = sum(1 for a in analyses if a.credit_risk_flag)
    
    print(f"Statistics:")
    print(f"  Total Articles Analyzed: {len(analyses)}")
    print(f"  Average Sentiment Score: {avg_sentiment:.3f}")
    print(f"  Average Impact Score: {avg_impact:.3f}")
    print(f"  Regulatory Risk Flags: {regulatory_risk_count}")
    print(f"  Earnings Risk Flags: {earnings_risk_count}")
    print(f"  Credit Risk Flags: {credit_risk_count}")
    print()
    
    # Show top 10 by impact
    analyses.sort(key=lambda a: a.impact_score, reverse=True)
    print("Top 10 by Impact Score:")
    for i, analysis in enumerate(analyses[:10], 1):
        risks = []
        if analysis.regulatory_risk_flag:
            risks.append("REG")
        if analysis.earnings_risk_flag:
            risks.append("EARN")
        if analysis.credit_risk_flag:
            risks.append("CRED")
        risk_str = ",".join(risks) if risks else "None"
        print(f"  {i}. News ID: {analysis.news_id[:12]}... | Sentiment: {analysis.sentiment_score:+.3f} | Impact: {analysis.impact_score:.3f} | Risks: {risk_str}")


def query_symbols(session, news_ids=None):
    """Query symbol mappings."""
    mapping_repo = SymbolMapRepository()
    
    if news_ids:
        mappings = mapping_repo.get_mappings_for_news_ids(session, news_ids)
    else:
        # Get all mappings (we'll need to query directly)
        cursor = session.cursor()
        cursor.execute("SELECT news_id, symbol, match_score FROM symbol_matches ORDER BY match_score DESC LIMIT 100")
        from news_regime.domain.models import SymbolMatch
        mappings = []
        for row in cursor.fetchall():
            mappings.append(SymbolMatch(
                news_id=row['news_id'],
                symbol=row['symbol'],
                match_score=row['match_score']
            ))
    
    print_separator()
    print(f"Symbol Mappings ({len(mappings)} found)")
    print_separator()
    print()
    
    if not mappings:
        print("No symbol mappings found.")
        return
    
    # Group by symbol
    symbol_counts = {}
    for mapping in mappings:
        if mapping.symbol not in symbol_counts:
            symbol_counts[mapping.symbol] = []
        symbol_counts[mapping.symbol].append(mapping)
    
    print("Symbols by Article Count:")
    sorted_symbols = sorted(symbol_counts.items(), key=lambda x: len(x[1]), reverse=True)
    for symbol, maps in sorted_symbols[:20]:
        avg_score = sum(m.match_score for m in maps) / len(maps)
        print(f"  {symbol}: {len(maps)} articles (avg score: {avg_score:.3f})")


def query_recommendations(session, limit=20):
    """Query recent recommendations."""
    rec_repo = RecommendationRepository()
    recommendations = rec_repo.get_latest_recommendations(session, limit)
    
    print_separator()
    print(f"Recent Recommendations ({len(recommendations)} found)")
    print_separator()
    print()
    
    if not recommendations:
        print("No recommendations found.")
        return
    
    for i, rec in enumerate(recommendations, 1):
        print(f"{i}. {rec.symbol} - {rec.status}")
        print(f"   Created: {rec.created_at}")
        print(f"   Sentiment: {rec.sentiment_score:+.3f} | Impact: {rec.impact_score:.3f} | Composite: {rec.composite_score:.3f}")
        if rec.risk_summary:
            print(f"   Risks: {rec.risk_summary}")
        if rec.reason_summary:
            print(f"   Reason: {rec.reason_summary}")
        print()


def query_regime(session, limit=10):
    """Query regime history."""
    regime_repo = RegimeRepository()
    regimes = regime_repo.get_recent_regimes(session, limit)
    
    print_separator()
    print(f"Regime History ({len(regimes)} found)")
    print_separator()
    print()
    
    if not regimes:
        print("No regime data found.")
        return
    
    for i, regime in enumerate(regimes, 1):
        print(f"{i}. {regime.timestamp} - {regime.regime_label} (confidence: {regime.confidence:.2%})")
        if regime.explanation:
            print(f"   {regime.explanation}")
        print()


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Query the news regime database")
    parser.add_argument('query_type', choices=['news', 'analysis', 'symbols', 'recommendations', 'regime', 'all'],
                       help='Type of data to query')
    parser.add_argument('--hours', type=int, default=24,
                       help='Time window in hours for news/analysis queries (default: 24)')
    parser.add_argument('--limit', type=int, default=50,
                       help='Maximum number of results to display (default: 50)')
    
    args = parser.parse_args()
    
    config = get_config()
    session_manager = DbSessionManager(config.db)
    session = session_manager.create_session()
    
    try:
        if args.query_type == 'news' or args.query_type == 'all':
            query_news(session, hours=args.hours, limit=args.limit)
            
        if args.query_type == 'analysis' or args.query_type == 'all':
            query_analysis(session, hours=args.hours)
            
        if args.query_type == 'symbols' or args.query_type == 'all':
            query_symbols(session)
            
        if args.query_type == 'recommendations' or args.query_type == 'all':
            query_recommendations(session, limit=args.limit)
            
        if args.query_type == 'regime' or args.query_type == 'all':
            query_regime(session, limit=args.limit)
            
    finally:
        session.close()


if __name__ == "__main__":
    main()
