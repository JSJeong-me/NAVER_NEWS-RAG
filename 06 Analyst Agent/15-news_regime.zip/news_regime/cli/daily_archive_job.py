
from __future__ import annotations
from datetime import datetime

from news_regime.common.logging import setup_logging
from news_regime.common.time_utils import now_in_timezone
from news_regime.config.loader import get_config
from news_regime.storage.db import DbSessionManager
from news_regime.archive.planner import ArchivePlanner
from news_regime.archive.exporter import ArchiveExporter
from news_regime.archive.cleaner import ArchiveCleaner
from news_regime.archive.job import ArchiveJob


def main() -> None:
    config = get_config()
    setup_logging(config.log_level)
    session_manager = DbSessionManager(config.db)
    planner = ArchivePlanner(config.archive)
    exporter = ArchiveExporter()
    cleaner = ArchiveCleaner()
    job = ArchiveJob(session_manager, planner, exporter, cleaner)

    now = now_in_timezone(config.timezone)
    job.run(as_of=now)


if __name__ == "__main__":
    main()
