#!/usr/bin/env python
"""CLI tool to retrieve and display the latest news from the database."""

from __future__ import annotations
import sys
from datetime import datetime, timedelta

from news_regime.config.loader import get_config
from news_regime.storage.db import DbSessionManager
from news_regime.storage.repositories.news_repo import NewsRepository


def main():
    """Display latest news articles from the database."""
    config = get_config()
    session_manager = DbSessionManager(config.db)
    news_repo = NewsRepository()
    
    # Get connection
    session = session_manager.create_session()
    
    # Get all news articles (we'll sort them ourselves)
    cursor = session.cursor()
    cursor.execute("""
        SELECT id, title, url, publisher, category, summary, published_at, crawled_at
        FROM news_meta
        ORDER BY crawled_at DESC
        LIMIT 50
    """)
    
    rows = cursor.fetchall()
    
    articles = []
    for row in rows:
        from news_regime.domain.models import NewsArticleMeta
        # Parse datetime strings if they're not already datetime objects
        published_at = row['published_at']
        crawled_at = row['crawled_at']
        if isinstance(published_at, str):
            published_at = datetime.fromisoformat(published_at)
        if isinstance(crawled_at, str):
            crawled_at = datetime.fromisoformat(crawled_at)
                
        articles.append(NewsArticleMeta(
            id=row['id'],
            title=row['title'],
            url=row['url'],
            publisher=row['publisher'],
            category=row['category'],
            summary=row['summary'],
            published_at=published_at,
            crawled_at=crawled_at
        ))
    
    if not articles:
        print("No news articles found in the last 24 hours.")
        session.close()
        return
    
    # Sort by crawled_at descending
    articles.sort(key=lambda a: a.crawled_at, reverse=True)
    
    print(f"\n{'='*80}")
    print(f"Latest News Articles ({len(articles)} found)")
    print(f"{'='*80}\n")
    
    for i, article in enumerate(articles, 1):
        print(f"{i}. {article.title}")
        print(f"   Publisher: {article.publisher or 'N/A'}")
        print(f"   Category: {article.category or 'N/A'}")
        print(f"   Crawled: {article.crawled_at}")
        print(f"   URL: {article.url}")
        if article.summary:
            # Truncate summary if too long
            summary = article.summary[:200] + "..." if len(article.summary) > 200 else article.summary
            print(f"   Summary: {summary}")
        print()
    
    session.close()


if __name__ == "__main__":
    main()
