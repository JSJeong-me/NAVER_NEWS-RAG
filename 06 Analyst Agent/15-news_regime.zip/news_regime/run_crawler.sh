#!/bin/bash
# Simple wrapper to run the crawler with proper Python module execution

cd /home/ubuntu/news_regime

echo "============================================================"
echo "  Naver Finance News Crawler"
echo "============================================================"
echo ""

# Check if package is installed
# if ! python -c "import cli.hourly_job" 2>/dev/null; then
#     echo "⚠ Package not properly set up. Installing..."
#     pip install -e . --quiet
#     echo "✓ Package installed"
#     echo ""
# fi

# Run the crawler
export PYTHONPATH=$PYTHONPATH:$(pwd)
python << 'PYTHON_EOF'
import sys
import os

# Ensure we're in the right directory
os.chdir('/home/ubuntu/news_regime')
sys.path.insert(0, os.getcwd())

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from cli.hourly_job import HourlyJob

print("=" * 60)
print("STEP 1: Crawling Naver Finance News")
print("=" * 60)

job = HourlyJob()
job.run_once()

print("\n" + "=" * 60)
print("STEP 2: Searching Archived News")
print("=" * 60)

session = job.session_manager.create_session()

# Search by keyword
keyword = "삼성"  # Change this to search for different keywords
print(f"\nSearching for: '{keyword}'")

cursor = session.cursor()
cursor.execute(
    """
    SELECT id, title, url, publisher, category, summary, published_at, crawled_at
    FROM news_meta
    WHERE title LIKE ?
    ORDER BY crawled_at DESC
    LIMIT 20
    """,
    (f"%{keyword}%",),
)
results = cursor.fetchall()

print(f"Found {len(results)} articles matching '{keyword}'")

for i, row in enumerate(results[:5], 1):
    print(f"\n{i}. {row['title']}")
    print(f"   Publisher: {row['publisher']}")
    print(f"   Published: {row['published_at']}")
    print(f"   URL: {row['url']}")

# Show recommendations
print("\n" + "=" * 60)
print("STEP 3: Buy Recommendations")
print("=" * 60)

import json
cursor.execute(
    """
    SELECT symbol, created_at, sentiment_score, impact_score,
           composite_score, risk_summary, status, reason_summary
    FROM recommendations
    ORDER BY created_at DESC
    LIMIT 5
    """
)
recommendations = cursor.fetchall()

if recommendations:
    print(f"Generated {len(recommendations)} buy recommendations:\n")
    for i, rec in enumerate(recommendations, 1):
        # Get symbol name
        symbol_names = {
            "005930": "삼성전자",
            "000660": "SK하이닉스",
            "005380": "현대차",
            "051910": "LG화학",
            "035720": "카카오",
            "035420": "NAVER"
        }
        symbol_name = symbol_names.get(rec['symbol'], rec['symbol'])
        risk_summary = json.loads(rec['risk_summary']) if rec['risk_summary'] else {}
        
        print(f"{i}. {symbol_name} ({rec['symbol']})")
        print(f"   Composite Score: {rec['composite_score']:.2f}")
        print(f"   Sentiment: {rec['sentiment_score']:+.2f}")
        print(f"   Impact: {rec['impact_score']:.2f}")
        if risk_summary:
            print(f"   Risk: {risk_summary}")
        print(f"   Reason: {rec['reason_summary']}")
        print()
else:
    print("No buy recommendations generated.")
    print("(This may happen if there's insufficient positive news)")

# Show regime
print("=" * 60)
print("STEP 4: Market Regime")
print("=" * 60)

cursor.execute(
    """
    SELECT timestamp, regime_label, confidence, explanation
    FROM regime_history
    ORDER BY timestamp DESC
    LIMIT 1
    """
)
latest_regime = cursor.fetchone()

if latest_regime:
    print(f"\nCurrent Market Regime: {latest_regime['regime_label'].upper()}")
    print(f"Confidence: {latest_regime['confidence']:.2f}")
    print(f"Explanation: {latest_regime['explanation']}")
else:
    print("No regime classification available.")

print("\n" + "=" * 60)
print("✓ Crawl complete!")
print("=" * 60)
PYTHON_EOF
