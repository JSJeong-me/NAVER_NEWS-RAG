# Quick Reference - News Regime SQL Tools

## 🚀 Quick Start

```bash
cd /home/ubuntu/news_regime

# Run the crawler (collects and analyzes news)
./run_crawler.sh

# View all data
./query_db.sh all
```

## 📊 Query Commands

### News Articles
```bash
./query_db.sh news                    # Last 24 hours
./query_db.sh news --hours 48         # Last 48 hours
./query_db.sh news --limit 10         # Limit to 10 results
./list_news.sh                        # Simple listing
```

### Sentiment & Risk Analysis
```bash
./query_db.sh analysis                # Statistics and top articles
./query_db.sh analysis --hours 48     # Last 48 hours
```

### Symbol Mappings
```bash
./query_db.sh symbols                 # All symbol-to-news mappings
```

### Trading Recommendations
```bash
./query_db.sh recommendations         # Recent recommendations
./query_db.sh recommendations --limit 50  # More results
```

### Market Regime
```bash
./query_db.sh regime                  # Recent regime classifications
./query_db.sh regime --limit 20       # More history
```

### Everything at Once
```bash
./query_db.sh all                     # All data types
./query_db.sh all --hours 48 --limit 5  # Custom time/limit
```

## 📁 File Locations

| File | Description |
|------|-------------|
| `/home/ubuntu/news_regime/news_regime.db` | SQLite database |
| `/home/ubuntu/news_regime/query_db.sh` | Query tool |
| `/home/ubuntu/news_regime/list_news.sh` | Simple news list |
| `/home/ubuntu/news_regime/run_crawler.sh` | Crawler script |

## 📖 Documentation

| Document | Description |
|----------|-------------|
| `SQL_DOCUMENTATION.md` | Complete SQL reference |
| `SQL_IMPLEMENTATION_SUMMARY.md` | Implementation overview |
| `HOWTO_RUN.md` | How to run the project |
| `README.md` | Project overview |

## 🔧 Python API

```python
from news_regime.config.loader import get_config
from news_regime.storage.db import DbSessionManager
from news_regime.storage.repositories.news_repo import NewsRepository
from datetime import datetime, timedelta

# Setup
config = get_config()
session_manager = DbSessionManager(config.db)
session = session_manager.create_session()

# Query
news_repo = NewsRepository()
end = datetime.now()
start = end - timedelta(hours=24)
articles = news_repo.get_news_in_window(session, start, end)

# Use results
for article in articles:
    print(f"{article.title} - {article.publisher}")

# Cleanup
session.close()
```

## 📊 Available Repositories

```python
from news_regime.storage.repositories.news_repo import NewsRepository
from news_regime.storage.repositories.analysis_repo import AnalysisRepository
from news_regime.storage.repositories.mapping_repo import SymbolMapRepository
from news_regime.storage.repositories.recommendation_repo import RecommendationRepository
from news_regime.storage.repositories.regime_repo import RegimeRepository
```

## 🗄️ Database Schema

### Tables
- `news_meta` - Article metadata (title, URL, publisher, etc.)
- `news_detail` - Full article content
- `symbol_matches` - News-to-stock-symbol mappings
- `article_analysis` - Sentiment and risk scores
- `recommendations` - Trading recommendations
- `regime_history` - Market regime classifications

## 💡 Common Tasks

### Check Latest News
```bash
./list_news.sh
```

### Get Market Sentiment
```bash
./query_db.sh analysis
```

### See Stock Recommendations
```bash
./query_db.sh recommendations
```

### Check Market Regime
```bash
./query_db.sh regime
```

### Full Report
```bash
./query_db.sh all --hours 24 --limit 10
```

## 🔍 Troubleshooting

### Module Not Found Error
```bash
cd /home/ubuntu/news_regime
pip install -e .
```

### Database Locked
- Close all open sessions
- Check for running processes
- Restart if needed

### No Data Found
```bash
# Run the crawler first
./run_crawler.sh
```

## 📈 Current Status

Run this to see current database status:
```bash
./query_db.sh all --limit 3
```

---

**For detailed documentation, see `SQL_DOCUMENTATION.md`**
