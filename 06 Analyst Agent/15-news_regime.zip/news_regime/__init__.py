"""
news_regime: Naver Finance main news crawler + LLM-based
analysis/recommendation skeleton package.
"""
