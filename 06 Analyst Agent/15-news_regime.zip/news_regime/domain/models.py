
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict


@dataclass
class NewsArticleMeta:
    """Lightweight metadata extracted from Naver mainnews list."""
    id: Optional[str]
    title: str
    url: str
    publisher: Optional[str]
    category: Optional[str]
    summary: Optional[str]
    published_at: datetime
    crawled_at: datetime


@dataclass
class NewsArticleDetail:
    """Full article including body text and reporter info."""
    meta: NewsArticleMeta
    body_text: str
    reporter: Optional[str] = None
    tags: Optional[List[str]] = None


@dataclass
class SymbolMatch:
    """Mapping between a news article and a single symbol."""
    news_id: Optional[str]
    symbol: str
    match_score: float


@dataclass
class ArticleSentiment:
    """Article-level sentiment and risk signals."""
    news_id: str
    sentiment_score: float
    regulatory_risk_flag: bool
    earnings_risk_flag: bool
    credit_risk_flag: bool
    impact_score: float


@dataclass
class SymbolAggregatedStats:
    """Aggregated news statistics for a symbol in a time window."""
    symbol: str
    window_start: datetime
    window_end: datetime
    num_articles: int
    avg_sentiment: float
    max_sentiment: float
    avg_impact: float
    max_impact: float
    regulatory_risk_ratio: float
    earnings_risk_ratio: float
    credit_risk_ratio: float
    last_article_time: Optional[datetime]


@dataclass
class RecommendationItem:
    """One buy candidate with scores and natural language reason."""
    symbol: str
    created_at: datetime
    sentiment_score: float
    impact_score: float
    composite_score: float
    risk_summary: Dict[str, float | bool] = field(default_factory=dict)
    status: str = "ACTIVE"
    reason_summary: str = ""


@dataclass
class RegimeStatus:
    """Global market regime classification snapshot."""
    timestamp: datetime
    regime_label: str
    confidence: float
    explanation: str


@dataclass
class GlobalNewsStats:
    """Global news statistics for regime decision."""
    window_start: datetime
    window_end: datetime
    num_articles: int
    avg_sentiment: float
    positive_ratio: float
    negative_ratio: float
    regulatory_risk_ratio: float
    earnings_risk_ratio: float
    credit_risk_ratio: float
    macro_news_ratio: float
    sector_news_ratio: float
    single_stock_news_ratio: float
