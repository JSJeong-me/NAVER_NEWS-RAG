# SQL Database Documentation

## Overview

The `news_regime` project uses **SQLite** for persistent storage of news articles, analysis results, recommendations, and market regime classifications.

## Database Schema

### Tables

#### 1. `news_meta`
Stores metadata for news articles.

| Column | Type | Description |
|--------|------|-------------|
| `id` | TEXT PRIMARY KEY | Unique article ID |
| `title` | TEXT | Article title |
| `url` | TEXT UNIQUE | Article URL |
| `publisher` | TEXT | Publisher name |
| `category` | TEXT | Article category |
| `summary` | TEXT | Article summary |
| `published_at` | TIMESTAMP | Publication timestamp |
| `crawled_at` | TIMESTAMP | Crawl timestamp |

#### 2. `news_detail`
Stores full article content.

| Column | Type | Description |
|--------|------|-------------|
| `news_id` | TEXT PRIMARY KEY | Foreign key to `news_meta.id` |
| `body_text` | TEXT | Full article text |
| `reporter` | TEXT | Reporter name |
| `tags` | TEXT | Comma-separated tags |

#### 3. `symbol_matches`
Maps news articles to stock symbols.

| Column | Type | Description |
|--------|------|-------------|
| `news_id` | TEXT | Foreign key to `news_meta.id` |
| `symbol` | TEXT | Stock symbol (e.g., "005930") |
| `match_score` | REAL | Confidence score (0.0-1.0) |

Primary key: `(news_id, symbol)`

#### 4. `article_analysis`
Stores sentiment and risk analysis results.

| Column | Type | Description |
|--------|------|-------------|
| `news_id` | TEXT PRIMARY KEY | Foreign key to `news_meta.id` |
| `sentiment_score` | REAL | Sentiment score (-1.0 to +1.0) |
| `regulatory_risk_flag` | BOOLEAN | Regulatory risk detected |
| `earnings_risk_flag` | BOOLEAN | Earnings risk detected |
| `credit_risk_flag` | BOOLEAN | Credit risk detected |
| `impact_score` | REAL | Impact score (0.0-1.0) |

#### 5. `recommendations`
Stores trading recommendations.

| Column | Type | Description |
|--------|------|-------------|
| `id` | INTEGER PRIMARY KEY | Auto-increment ID |
| `symbol` | TEXT | Stock symbol |
| `created_at` | TIMESTAMP | Creation timestamp |
| `sentiment_score` | REAL | Aggregated sentiment |
| `impact_score` | REAL | Aggregated impact |
| `composite_score` | REAL | Combined score |
| `risk_summary` | TEXT | JSON risk summary |
| `status` | TEXT | Recommendation status |
| `reason_summary` | TEXT | Explanation text |

#### 6. `regime_history`
Stores market regime classifications.

| Column | Type | Description |
|--------|------|-------------|
| `timestamp` | TIMESTAMP PRIMARY KEY | Classification time |
| `regime_label` | TEXT | Regime type (e.g., "risk_on", "risk_off") |
| `confidence` | REAL | Confidence level (0.0-1.0) |
| `explanation` | TEXT | Explanation text |

## Repository Pattern

The project uses the **Repository Pattern** to abstract database access:

### Available Repositories

1. **`NewsRepository`** (`storage/repositories/news_repo.py`)
   - `exists_by_url(session, url)` - Check if article exists
   - `insert_news_meta(session, meta)` - Insert news metadata
   - `insert_news_detail(session, detail, news_id)` - Insert article content
   - `get_news_in_window(session, start, end)` - Query news by time range

2. **`AnalysisRepository`** (`storage/repositories/analysis_repo.py`)
   - `insert_article_analysis(session, analyses)` - Insert analysis results
   - `get_article_analysis_in_window(session, start, end)` - Query analysis by time

3. **`SymbolMapRepository`** (`storage/repositories/mapping_repo.py`)
   - `insert_mappings(session, mappings)` - Insert symbol mappings
   - `get_mappings_for_news_ids(session, news_ids)` - Get mappings for articles

4. **`RecommendationRepository`** (`storage/repositories/recommendation_repo.py`)
   - `insert_recommendations(session, items)` - Insert recommendations
   - `get_latest_recommendations(session, limit)` - Get recent recommendations

5. **`RegimeRepository`** (`storage/repositories/regime_repo.py`)
   - `insert_regime(session, regime)` - Insert regime classification
   - `get_recent_regimes(session, limit)` - Get recent regime history

## Usage Examples

### Basic Query

```python
from news_regime.config.loader import get_config
from news_regime.storage.db import DbSessionManager
from news_regime.storage.repositories.news_repo import NewsRepository
from datetime import datetime, timedelta

# Setup
config = get_config()
session_manager = DbSessionManager(config.db)
session = session_manager.create_session()
news_repo = NewsRepository()

# Query news from last 24 hours
end_time = datetime.now()
start_time = end_time - timedelta(hours=24)
articles = news_repo.get_news_in_window(session, start_time, end_time)

# Process results
for article in articles:
    print(f"{article.title} - {article.publisher}")

# Cleanup
session.close()
```

### Insert Data

```python
from news_regime.domain.models import NewsArticleMeta
from datetime import datetime

# Create article metadata
meta = NewsArticleMeta(
    id=None,  # Will be auto-generated
    title="Example Article",
    url="https://example.com/article",
    publisher="Example Publisher",
    category="Business",
    summary="This is a summary",
    published_at=datetime.now(),
    crawled_at=datetime.now()
)

# Insert
news_id = news_repo.insert_news_meta(session, meta)
print(f"Inserted article with ID: {news_id}")
session.close()
```

### Complex Query with Joins

```python
from news_regime.storage.repositories.analysis_repo import AnalysisRepository

analysis_repo = AnalysisRepository()

# Get analysis for articles in time window
analyses = analysis_repo.get_article_analysis_in_window(session, start_time, end_time)

# Calculate statistics
avg_sentiment = sum(a.sentiment_score for a in analyses) / len(analyses)
risk_count = sum(1 for a in analyses if a.regulatory_risk_flag)

print(f"Average sentiment: {avg_sentiment:.3f}")
print(f"Articles with regulatory risk: {risk_count}")
```

## CLI Query Tools

The project provides convenient CLI tools for querying the database:

### `query_db.sh`

Comprehensive query tool with multiple modes:

```bash
# Query news articles
./query_db.sh news --hours 24 --limit 50

# Query analysis statistics
./query_db.sh analysis --hours 24

# Query symbol mappings
./query_db.sh symbols

# Query recommendations
./query_db.sh recommendations --limit 20

# Query regime history
./query_db.sh regime --limit 10

# Query everything
./query_db.sh all --hours 24 --limit 10
```

### `list_news.sh`

Simple news listing tool:

```bash
./list_news.sh
```

## Database Configuration

Database settings are configured in `config/defaults.py`:

```python
db:
  dsn: "sqlite:///news_regime.db"  # Database file path
  echo: false                       # SQL query logging
  pool_size: 5                      # Connection pool size
  timeout: 30.0                     # Query timeout (seconds)
```

### Database Location

By default, the database is created at:
- `/home/ubuntu/news_regime/news_regime.db` (when using relative path)
- Or as specified in the `dsn` configuration

## DateTime Handling

The project uses SQLite's datetime adapters for proper timestamp handling:

```python
# Registered in storage/db.py
sqlite3.register_adapter(datetime, adapt_datetime)
sqlite3.register_converter("TIMESTAMP", convert_datetime)
```

This ensures:
- Python `datetime` objects are stored as ISO format strings
- Retrieved timestamps are automatically converted back to `datetime` objects
- Timezone-aware timestamps are properly handled

## Best Practices

1. **Always close sessions**: Use try-finally or context managers
   ```python
   session = session_manager.create_session()
   try:
       # Your queries here
       pass
   finally:
       session.close()
   ```

2. **Use repositories**: Don't write raw SQL in business logic
   ```python
   # Good
   articles = news_repo.get_news_in_window(session, start, end)
   
   # Avoid
   cursor.execute("SELECT * FROM news_meta WHERE ...")
   ```

3. **Batch inserts**: Use `executemany()` for multiple inserts
   ```python
   # Good (in repositories)
   cursor.executemany("INSERT INTO ...", data)
   
   # Avoid
   for item in items:
       cursor.execute("INSERT INTO ...", item)
   ```

4. **Foreign key constraints**: Enabled by default
   ```python
   conn.execute("PRAGMA foreign_keys = ON")
   ```

## Troubleshooting

### Import Errors

If you see `ModuleNotFoundError: No module named 'news_regime'`:

```bash
cd /home/ubuntu/news_regime
pip install -e .
```

Or use the wrapper scripts which handle this automatically.

### Database Locked

If you get "database is locked" errors:
- Ensure you're closing all sessions properly
- Check for long-running transactions
- Consider increasing the timeout in config

### Schema Changes

To reset the database schema:

```bash
rm news_regime.db
python -c "from news_regime.config.loader import get_config; from news_regime.storage.db import DbSessionManager; DbSessionManager(get_config().db)"
```

This will recreate all tables with the current schema.
