
from __future__ import annotations
from datetime import datetime
from typing import Optional

from news_regime.config.models import RegimeConfig
from news_regime.domain.models import GlobalNewsStats, RegimeStatus


class RegimeClassifier:
    """Rule-based regime classifier with optional LLM explanation."""

    def __init__(self, config: RegimeConfig, summarizer: Optional[object] = None) -> None:
        self.config = config
        self.summarizer = summarizer

    def classify(self, stats: GlobalNewsStats, as_of: datetime) -> RegimeStatus:
        """Classify market regime based on global news statistics."""
        # Bullish regime: high positive sentiment, low risk
        if (stats.avg_sentiment > self.config.bullish_sentiment_threshold and
            stats.regulatory_risk_ratio < self.config.high_risk_ratio_threshold):
            regime_label = "risk_on"
            confidence = 0.8
            explanation = "전반적으로 긍정적 뉴스, 낮은 리스크 비율"
        
        # Bearish regime: high negative sentiment or high risk
        elif (stats.avg_sentiment < self.config.bearish_sentiment_threshold or
              stats.regulatory_risk_ratio > self.config.high_risk_ratio_threshold):
            regime_label = "risk_off"
            confidence = 0.8
            explanation = "부정적 뉴스 또는 높은 리스크 비율"
        
        # Sideways/unknown
        else:
            regime_label = "sideways"
            confidence = 0.6
            explanation = "중립적 시장 심리"
        
        return RegimeStatus(
            timestamp=as_of,
            regime_label=regime_label,
            confidence=confidence,
            explanation=explanation,
        )
