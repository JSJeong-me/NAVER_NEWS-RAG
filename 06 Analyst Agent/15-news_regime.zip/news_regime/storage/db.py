

from __future__ import annotations
from typing import Any
from news_regime.config.models import DbConfig


import sqlite3
import logging
from datetime import datetime
from news_regime.config.models import DbConfig

logger = logging.getLogger(__name__)

# Register datetime adapters for SQLite
def adapt_datetime(dt):
    """Convert datetime to ISO format string for SQLite."""
    return dt.isoformat()

def convert_datetime(s):
    """Convert ISO format string back to datetime."""
    if isinstance(s, bytes):
        s = s.decode('utf-8')
    return datetime.fromisoformat(s)

sqlite3.register_adapter(datetime, adapt_datetime)
sqlite3.register_converter("TIMESTAMP", convert_datetime)


class DbSessionManager:
    """Manages SQLite database connection and schema initialization."""

    def __init__(self, config: DbConfig) -> None:
        self.config = config
        self._init_db()

    def _init_db(self) -> None:
        """Initialize database schema if not exists."""
        conn = self.create_session()
        cursor = conn.cursor()
        
        # News Meta
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS news_meta (
                id TEXT PRIMARY KEY,
                title TEXT,
                url TEXT UNIQUE,
                publisher TEXT,
                category TEXT,
                summary TEXT,
                published_at TIMESTAMP,
                crawled_at TIMESTAMP
            )
        """)
        
        # News Detail
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS news_detail (
                news_id TEXT PRIMARY KEY,
                body_text TEXT,
                reporter TEXT,
                tags TEXT,
                FOREIGN KEY(news_id) REFERENCES news_meta(id)
            )
        """)
        
        # Symbol Matches
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS symbol_matches (
                news_id TEXT,
                symbol TEXT,
                match_score REAL,
                PRIMARY KEY (news_id, symbol),
                FOREIGN KEY(news_id) REFERENCES news_meta(id)
            )
        """)
        
        # Article Analysis (Sentiment/Risk/Impact)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS article_analysis (
                news_id TEXT PRIMARY KEY,
                sentiment_score REAL,
                regulatory_risk_flag BOOLEAN,
                earnings_risk_flag BOOLEAN,
                credit_risk_flag BOOLEAN,
                impact_score REAL,
                FOREIGN KEY(news_id) REFERENCES news_meta(id)
            )
        """)
        
        # Recommendations
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS recommendations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT,
                created_at TIMESTAMP,
                sentiment_score REAL,
                impact_score REAL,
                composite_score REAL,
                risk_summary TEXT,
                status TEXT,
                reason_summary TEXT
            )
        """)
        
        # Regime History
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS regime_history (
                timestamp TIMESTAMP PRIMARY KEY,
                regime_label TEXT,
                confidence REAL,
                explanation TEXT
            )
        """)
        
        conn.commit()
        conn.close()

    def create_session(self) -> sqlite3.Connection:
        """Return a new SQLite connection."""
        # Parse DSN to get filename, e.g. "sqlite:///news_regime.db" -> "news_regime.db"
        # If "memory://", use ":memory:"
        dsn = self.config.dsn
        if dsn.startswith("sqlite:///"):
            db_path = dsn.replace("sqlite:///", "")
        elif dsn == "memory://":
            db_path = ":memory:"
        else:
            db_path = "news_regime.db"  # Fallback
            
        conn = sqlite3.connect(
            db_path,
            detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES
        )
        # Enable foreign keys
        conn.execute("PRAGMA foreign_keys = ON")
        # Return rows as Row objects for easier access
        conn.row_factory = sqlite3.Row
        return conn
