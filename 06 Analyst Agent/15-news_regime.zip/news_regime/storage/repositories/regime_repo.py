
from __future__ import annotations
from typing import List

from news_regime.domain.models import RegimeStatus


class RegimeRepository:
    """Persist regime classification history."""

    def insert_regime(self, session, regime: RegimeStatus) -> None:
        """Insert regime classification."""
        cursor = session.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO regime_history (timestamp, regime_label, confidence, explanation)
            VALUES (?, ?, ?, ?)
        """, (regime.timestamp, regime.regime_label, regime.confidence, regime.explanation))
        session.commit()

    def get_recent_regimes(self, session, limit: int = 50) -> List[RegimeStatus]:
        """Get recent regime classifications sorted by timestamp."""
        cursor = session.cursor()
        cursor.execute("""
            SELECT timestamp, regime_label, confidence, explanation
            FROM regime_history
            ORDER BY timestamp DESC
            LIMIT ?
        """, (limit,))
        
        results = []
        for row in cursor.fetchall():
            results.append(RegimeStatus(
                timestamp=row['timestamp'],
                regime_label=row['regime_label'],
                confidence=row['confidence'],
                explanation=row['explanation']
            ))
        return results
