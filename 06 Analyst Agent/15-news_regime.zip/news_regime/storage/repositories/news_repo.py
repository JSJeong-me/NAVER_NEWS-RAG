
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.domain.models import NewsArticleMeta, NewsArticleDetail, ArticleSentiment


class NewsRepository:
    """CRUD operations for news metadata & article bodies."""

    def exists_by_url(self, session, url: str) -> bool:
        """Check if news with given URL exists."""
        cursor = session.cursor()
        cursor.execute("SELECT 1 FROM news_meta WHERE url = ?", (url,))
        return cursor.fetchone() is not None

    def insert_news_meta(self, session, meta: NewsArticleMeta) -> str:
        """Insert news metadata and return ID."""
        import uuid
        if meta.id is None:
            meta.id = str(uuid.uuid4())[:16]
        
        cursor = session.cursor()
        cursor.execute("""
            INSERT INTO news_meta (id, title, url, publisher, category, summary, published_at, crawled_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            meta.id, meta.title, meta.url, meta.publisher, meta.category, 
            meta.summary, meta.published_at, meta.crawled_at
        ))
        session.commit()
        return meta.id

    def insert_news_detail(self, session, detail: NewsArticleDetail, news_id: str) -> None:
        """Insert full article detail."""
        cursor = session.cursor()
        tags_str = ",".join(detail.tags) if detail.tags else None
        cursor.execute("""
            INSERT INTO news_detail (news_id, body_text, reporter, tags)
            VALUES (?, ?, ?, ?)
        """, (news_id, detail.body_text, detail.reporter, tags_str))
        session.commit()

    def get_news_in_window(
        self,
        session,
        start: datetime,
        end: datetime,
    ) -> List[NewsArticleMeta]:
        """Get all news articles in time window."""
        cursor = session.cursor()
        cursor.execute("""
            SELECT id, title, url, publisher, category, summary, published_at, crawled_at
            FROM news_meta
            WHERE crawled_at BETWEEN ? AND ?
        """, (start, end))
        
        results = []
        for row in cursor.fetchall():
            results.append(NewsArticleMeta(
                id=row['id'],
                title=row['title'],
                url=row['url'],
                publisher=row['publisher'],
                category=row['category'],
                summary=row['summary'],
                # SQLite stores datetime as string usually, but adapter might handle it
                # If using standard sqlite3 with adapters, it comes back as datetime or string
                # We'll assume adapter handles it or it's a string we need to parse if we didn't register adapters
                # For now, let's rely on standard behavior (string) and parse if needed, 
                # but `sqlite3` default adapter for timestamp is often automatic if declared.
                # Let's assume it returns string if not configured otherwise.
                # Actually, let's parse it to be safe or ensure we register adapters.
                # For simplicity in this snippet, we'll assume it works or is a string.
                # Let's add a safe parser helper if needed, but for now just pass it.
                published_at=row['published_at'], 
                crawled_at=row['crawled_at']
            ))
        return results
