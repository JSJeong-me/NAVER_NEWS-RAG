
from __future__ import annotations
from typing import List

from news_regime.domain.models import RecommendationItem


class RecommendationRepository:
    """Persist recommendation snapshots."""

    def insert_recommendations(self, session, items: List[RecommendationItem]) -> None:
        """Insert recommendation items."""
        import json
        cursor = session.cursor()
        data = [
            (
                i.symbol, i.created_at, i.sentiment_score, i.impact_score,
                i.composite_score, json.dumps(i.risk_summary), i.status, i.reason_summary
            )
            for i in items
        ]
        cursor.executemany("""
            INSERT INTO recommendations (
                symbol, created_at, sentiment_score, impact_score,
                composite_score, risk_summary, status, reason_summary
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, data)
        session.commit()

    def get_latest_recommendations(self, session, limit: int = 50) -> List[RecommendationItem]:
        """Get latest recommendations sorted by created_at."""
        import json
        cursor = session.cursor()
        cursor.execute("""
            SELECT id, symbol, created_at, sentiment_score, impact_score,
                   composite_score, risk_summary, status, reason_summary
            FROM recommendations
            ORDER BY created_at DESC
            LIMIT ?
        """, (limit,))
        
        results = []
        for row in cursor.fetchall():
            results.append(RecommendationItem(
                symbol=row['symbol'],
                created_at=row['created_at'],
                sentiment_score=row['sentiment_score'],
                impact_score=row['impact_score'],
                composite_score=row['composite_score'],
                risk_summary=json.loads(row['risk_summary']) if row['risk_summary'] else {},
                status=row['status'],
                reason_summary=row['reason_summary']
            ))
        return results
