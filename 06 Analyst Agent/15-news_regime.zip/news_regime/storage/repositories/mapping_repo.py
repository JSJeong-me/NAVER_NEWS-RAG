
from __future__ import annotations
from typing import List

from news_regime.domain.models import SymbolMatch


class SymbolMapRepository:
    """Persist news-symbol mapping rows."""

    def insert_mappings(self, session, mappings: List[SymbolMatch]) -> None:
        """Insert symbol mappings."""
        cursor = session.cursor()
        data = [
            (m.news_id, m.symbol, m.match_score)
            for m in mappings
        ]
        cursor.executemany("""
            INSERT OR IGNORE INTO symbol_matches (news_id, symbol, match_score)
            VALUES (?, ?, ?)
        """, data)
        session.commit()

    def get_mappings_for_news_ids(self, session, news_ids: List[str]) -> List[SymbolMatch]:
        """Get all mappings for given news IDs."""
        if not news_ids:
            return []
            
        cursor = session.cursor()
        # Dynamically build query for IN clause
        placeholders = ",".join("?" * len(news_ids))
        query = f"""
            SELECT news_id, symbol, match_score
            FROM symbol_matches
            WHERE news_id IN ({placeholders})
        """
        cursor.execute(query, news_ids)
        
        results = []
        for row in cursor.fetchall():
            results.append(SymbolMatch(
                news_id=row['news_id'],
                symbol=row['symbol'],
                match_score=row['match_score']
            ))
        return results
