
from __future__ import annotations
from datetime import datetime
from typing import List

from news_regime.domain.models import ArticleSentiment


class AnalysisRepository:
    """Persist article-level sentiment/risk/impact records."""

    def insert_article_analysis(self, session, analyses: List[ArticleSentiment]) -> None:
        """Insert article sentiment/risk analyses."""
        cursor = session.cursor()
        data = [
            (
                a.news_id, a.sentiment_score, a.regulatory_risk_flag,
                a.earnings_risk_flag, a.credit_risk_flag, a.impact_score
            )
            for a in analyses
        ]
        cursor.executemany("""
            INSERT OR REPLACE INTO article_analysis (
                news_id, sentiment_score, regulatory_risk_flag,
                earnings_risk_flag, credit_risk_flag, impact_score
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, data)
        session.commit()

    def get_article_analysis_in_window(
        self,
        session,
        start: datetime,
        end: datetime,
    ) -> List[ArticleSentiment]:
        """Get all analyses in time window."""
        # Join with news_meta to filter by time
        cursor = session.cursor()
        cursor.execute("""
            SELECT a.news_id, a.sentiment_score, a.regulatory_risk_flag,
                   a.earnings_risk_flag, a.credit_risk_flag, a.impact_score
            FROM article_analysis a
            JOIN news_meta m ON a.news_id = m.id
            WHERE m.crawled_at BETWEEN ? AND ?
        """, (start, end))
        
        results = []
        for row in cursor.fetchall():
            results.append(ArticleSentiment(
                news_id=row['news_id'],
                sentiment_score=row['sentiment_score'],
                regulatory_risk_flag=bool(row['regulatory_risk_flag']),
                earnings_risk_flag=bool(row['earnings_risk_flag']),
                credit_risk_flag=bool(row['credit_risk_flag']),
                impact_score=row['impact_score']
            ))
        return results
