from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional


@dataclass
class CliCommandResult:
    """Result of executing a shell command."""

    command: List[str]
    stdout: str
    stderr: str
    exit_code: int
    started_at: datetime
    finished_at: datetime
    success: bool


def run_crawler_command(timeout_seconds: Optional[int] = None) -> CliCommandResult:
    """Execute ./run_crawler.sh and capture its result.

    TODO:
        - Build absolute path to run_crawler.sh.
        - Use subprocess.run with timeout.
        - Populate CliCommandResult.
    """
    raise NotImplementedError("run_crawler_command is not yet implemented.")


def run_query_db_all(
    hours: int,
    limit: int,
    timeout_seconds: Optional[int] = None,
) -> CliCommandResult:
    """Execute ./query_db.sh all --hours H --limit N and capture its result.

    TODO:
        - Build absolute path to query_db.sh.
        - Use subprocess.run with timeout.
        - Populate CliCommandResult.
    """
    raise NotImplementedError("run_query_db_all is not yet implemented.")
