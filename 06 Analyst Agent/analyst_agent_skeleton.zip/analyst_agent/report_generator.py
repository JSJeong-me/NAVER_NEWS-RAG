from __future__ import annotations

from datetime import datetime

from .config import AnalystAgentConfig
from .llm_client import LlmClient
from .report_schema import AnalystCoreFindings, AnalystReport


def generate_analyst_report(
    core_findings: AnalystCoreFindings,
    config: AnalystAgentConfig,
    llm_client: LlmClient,
) -> AnalystReport:
    """Generate an AnalystReport from core findings using the LLM."""
    raise NotImplementedError("generate_analyst_report is not yet implemented.")
