from __future__ import annotations

from pathlib import Path
from typing import Dict

from .analysis_logic import build_core_findings
from .cli_tools import CliCommandResult, run_crawler_command, run_query_db_all
from .config import AnalystAgentConfig
from .llm_client import LlmClient
from .parse_query_output import build_db_snapshot
from .report_generator import generate_analyst_report
from .report_schema import AnalystReport


def run_analyst_cycle_once(config: AnalystAgentConfig) -> AnalystReport:
    """Run a single analysis cycle and return the resulting report."""
    raise NotImplementedError("run_analyst_cycle_once is not yet implemented.")


def save_analyst_report(
    report: AnalystReport,
    output_dir: str | Path | None = None,
) -> Path:
    """Persist the report to disk and return the resulting file path."""
    raise NotImplementedError("save_analyst_report is not yet implemented.")


def log_analyst_cycle(
    report: AnalystReport,
    cli_results: Dict[str, CliCommandResult],
    log_dir: str | Path | None = None,
) -> None:
    """Log summary information for an analysis cycle."""
    raise NotImplementedError("log_analyst_cycle is not yet implemented.")
