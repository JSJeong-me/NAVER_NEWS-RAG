from __future__ import annotations

import sys

from .config import load_analyst_agent_config
from .orchestrator import run_analyst_cycle_once, save_analyst_report


def main(argv: list[str] | None = None) -> int:
    """Entry point for running a single Analyst Agent cycle."""
    if argv is None:
        argv = sys.argv[1:]

    # TODO: parse argv for overrides (e.g. hours_window).
    config = load_analyst_agent_config()
    report = run_analyst_cycle_once(config)

    # For now, print the formatted report to stdout.
    print(report.formatted_text)

    save_analyst_report(report, output_dir=config.report_output_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
