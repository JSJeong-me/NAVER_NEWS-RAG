from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

from .config import LlmConfig
from .report_schema import AnalystCoreFindings


@dataclass
class LlmClient:
    """Thin wrapper around the OpenAI Agents SDK."""

    config: LlmConfig

    def generate_report_text(
        self,
        core_findings: AnalystCoreFindings,
        extra_context: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Generate a human-readable report using the LLM.

        TODO:
            - Convert core_findings to JSON-like dict.
            - Build prompt with clear section instructions.
            - Call Agents SDK and return response text.
        """
        raise NotImplementedError("LlmClient.generate_report_text is not implemented.")
