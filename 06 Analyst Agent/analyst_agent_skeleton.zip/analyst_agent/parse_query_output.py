from __future__ import annotations

from typing import Dict, List

from .models import (
    ArticleStats,
    DbSnapshot,
    NewsArticle,
    Recommendation,
    RegimeRecord,
    SymbolStats,
)


def split_query_all_output(raw_output: str) -> Dict[str, str]:
    """Split raw query_db.sh all output into logical sections.

    TODO:
        - Detect section headings.
        - Group following lines under each section key.
    """
    raise NotImplementedError("split_query_all_output is not yet implemented.")


def parse_news_section(section_text: str) -> List[NewsArticle]:
    """Parse the 'News Articles' section into NewsArticle objects."""
    raise NotImplementedError("parse_news_section is not yet implemented.")


def parse_article_analysis_section(section_text: str) -> ArticleStats:
    """Parse the 'Article Analysis' section into ArticleStats."""
    raise NotImplementedError("parse_article_analysis_section is not yet implemented.")


def parse_symbol_mappings_section(section_text: str) -> List[SymbolStats]:
    """Parse the 'Symbol Mappings' section into SymbolStats objects."""
    raise NotImplementedError("parse_symbol_mappings_section is not yet implemented.")


def parse_recommendations_section(section_text: str) -> List[Recommendation]:
    """Parse the 'Recent Recommendations' section into Recommendation objects."""
    raise NotImplementedError("parse_recommendations_section is not yet implemented.")


def parse_regime_history_section(section_text: str) -> List[RegimeRecord]:
    """Parse the 'Regime History' section into RegimeRecord objects."""
    raise NotImplementedError("parse_regime_history_section is not yet implemented.")


def build_db_snapshot(raw_output: str, hours_window: int) -> DbSnapshot:
    """Build a DbSnapshot from the combined query_db.sh all output.

    TODO:
        - Call split_query_all_output.
        - Parse each section.
        - Construct DbSnapshot.
    """
    raise NotImplementedError("build_db_snapshot is not yet implemented.")
