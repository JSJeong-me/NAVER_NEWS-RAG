from __future__ import annotations

from typing import List

from .config import AnalystAgentConfig
from .models import ArticleStats, DbSnapshot, Recommendation, RegimeRecord, SymbolStats
from .report_schema import (
    AnalystCoreFindings,
    FocusSymbol,
    KeyNewsDriver,
    RegimeChange,
    VolatilityAssessment,
)


def analyze_regime_change(
    regime_history: List[RegimeRecord],
    window_size: int,
) -> RegimeChange:
    """Analyze whether a regime change has recently occurred."""
    raise NotImplementedError("analyze_regime_change is not yet implemented.")


def assess_volatility(
    article_stats: ArticleStats,
    regime_history: List[RegimeRecord],
    config: AnalystAgentConfig,
) -> VolatilityAssessment:
    """Assess volatility level using article stats and regime history."""
    raise NotImplementedError("assess_volatility is not yet implemented.")


def select_top_recommendations(
    recommendations: List[Recommendation],
    max_count: int,
) -> List[Recommendation]:
    """Select top N recommendations based on composite score."""
    raise NotImplementedError("select_top_recommendations is not yet implemented.")


def identify_focus_symbols(
    symbol_stats: List[SymbolStats],
    recommendations: List[Recommendation],
    max_count: int,
) -> List[FocusSymbol]:
    """Identify symbols with concentrated news/sentiment."""
    raise NotImplementedError("identify_focus_symbols is not yet implemented.")


def extract_key_news_drivers(
    news,
    article_stats: ArticleStats,
    regime_history: List[RegimeRecord],
    max_count: int,
) -> List[KeyNewsDriver]:
    """Extract key news drivers from the full news list."""
    raise NotImplementedError("extract_key_news_drivers is not yet implemented.")


def build_core_findings(
    snapshot: DbSnapshot,
    config: AnalystAgentConfig,
) -> AnalystCoreFindings:
    """Build AnalystCoreFindings from a DbSnapshot and config."""
    raise NotImplementedError("build_core_findings is not yet implemented.")
