from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class VolatilityThresholdConfig:
    """Thresholds and heuristics used to classify volatility levels.

    All numeric values here are domain-specific and should be tuned
    experimentally. They are intentionally simple to keep the first
    implementation easy to reason about.
    """

    impact_normal_max: float = 0.1
    impact_caution_min: float = 0.15
    impact_spike_min: float = 0.3
    risk_flag_caution_ratio: float = 0.1
    risk_flag_spike_ratio: float = 0.3


@dataclass
class LlmConfig:
    """Configuration for the LLM / Agents SDK integration."""

    model: str = "gpt-5.1-mini"
    temperature: float = 0.3
    max_tokens: int = 2048
    request_timeout: float = 30.0
    response_format: Optional[str] = "text"


@dataclass
class AnalystAgentConfig:
    """Top-level configuration for the Analyst Agent runtime."""

    hours_window: int = 24
    news_limit: int = 50
    run_crawler_before_analysis: bool = True
    report_output_dir: str = "./reports"
    log_dir: str = "./logs"
    regime_window_size: int = 3
    volatility_thresholds: VolatilityThresholdConfig = VolatilityThresholdConfig()
    llm: LlmConfig = LlmConfig()
    scheduler_mode: str = "once"
    env_name: str = "prod"


def load_analyst_agent_config() -> AnalystAgentConfig:
    """Load configuration for the Analyst Agent.

    This function is responsible for:
    - Reading environment variables and/or configuration files.
    - Applying sensible defaults when configuration keys are missing.
    - Constructing and returning an AnalystAgentConfig instance.

    The skeleton simply returns a default config instance, which allows
    the rest of the agent code to be exercised in tests without requiring
    any external configuration to exist.
    """
    # TODO: Implement real configuration loading logic.
    return AnalystAgentConfig()
